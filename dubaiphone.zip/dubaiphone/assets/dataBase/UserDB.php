<?php
session_start();
require_once "allTabel.php";
function sanitize($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
    return $data;
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

if(isset($_POST['name'])){
    $name = sanitize($_POST['name']);
    if(strlen($name) < 6){
        echo "الاسم يجب ان يكون اكبر من 6 احرف <br>";
        $error = 1;
    }
}
    if(isset($_POST['username'])){
        $username = sanitize($_POST['username']);
    
        $db = new Database;
        $cehck_Username = $db->GetRow("SELECT username FROM `users` WHERE Username = ? LIMIT 1",[$username]);
        if($cehck_Username){
            echo "<br>هذا الاسم موجود من قبل , اختر اسم مستخدم جديد! <br>";
            $error = 1;
        }
        if(strlen($username) < 6){
            echo "اسم المستخدم يجب ان يكون اكبر من 6 احرف <br>";
            $error = 1;
        }
    
    }   
   

if(isset($_POST['email'])){
    $email = sanitize($_POST['email']);

    $db = new Database;
    $cehck_email = $db->GetRow("SELECT email FROM users WHERE email = ? LIMIT 1",[$email]);
    if($cehck_email){
        if(isset($_POST["create"]))
        {
            echo "<br>هذا الاسم موجود مسبقاً , اضف عنوان بريد جديد! <br>";
            $error = 1;
        }

        $find=1;
    }
    else
    {
        if(isset($_POST["login"]) || isset($_POST["forgetpassword"]))
        {
            $error = 1;
            echo "الايميل غير موجود<br>";
        }
    }

    if(!filter_var($email,FILTER_VALIDATE_EMAIL)){
        echo "<br>صيفه الايميل غير صحيحة";
        $error = 1;
    }
}

if(isset($_POST['password'])){

    $password = sanitize($_POST['password']);
    
    if(strlen($password) < 8){
        echo "<br>كلمة السر يجب ان تكون اكبر من 8 احرف<br>";
        $error = 1;
    }
    else
    {
        $password=md5($password);
        if(isset($_POST["login"]))
        {
            $db = new Database;
            $cehck_password = $db->GetRow("SELECT email,password,allow FROM users WHERE password = ? and email = ? LIMIT 1",[$password,$email]);
            if($cehck_password)
            {
            $pass=1;
            if(intval($cehck_password["allow"])==1)
            { 
            $allow=1;
           }
            }
            else 
            { $error=1;
                echo "كلمة السر غير صحيحة";
            }

    }
}
}
if(isset($_POST['Confpassword'])){
    $Confpassword = sanitize($_POST['Confpassword']);
    if(strlen($Confpassword) < 8){
        echo "<br>تاكيد كلمة السر يجب ان تكون اكبر من 8 احرف<br>";
        $error = 1;
    }
}

if(isset($_POST['phone'])){
    $phone = sanitize($_POST['phone']);

    $db = new Database;
    $cehck_phone = $db->GetRows("SELECT phone FROM `users` WHERE phone = ? LIMIT 1",[$phone]);
    if($cehck_phone){
        echo "<br>لقد تم اضافة هذا الرقم , اضف رقم جديد! <br>";
        $error = 1;
    }
    if(strlen($phone) < 6){
        echo "<br>الهاتف يجب ان يكون اكبر من 6  <br>";
        $error = 1;
    }

    
}
if(isset($_POST["create"])){
if($_POST['Confpassword']!=$_POST['password'])
{
    echo "<br>كلمة السر والتاكيد غير متوافقة <br>";
    $error = 1; 
}
}
if(isset($_POST["Code_pass"]))
{
    if($_SESSION["code_user"] !=$_POST["Code_pass"] )
    {
        $error =1;
        echo "الكود المدخل خاطى";
    }
    else
    {
        unset($_SESSION["code_user"]);
    }
}


if(!isset($error) && isset($_POST["create"]))
{
    $db = new Database();
    $add = $db->Insert("INSERT INTO users (name,Username,email,phone,password,allow)
    VALUES (?,?,?,?,?,?)",[$name,$username,$email,$phone,$password,0]);
    if($add){
            echo 1;

        }else{
           echo "لديك خطاء ";
        }
        
      
}
// Login User
if(isset($_POST["login"]) && !isset($error)){
    if(!isset($allow)){
if( isset($find)  && isset($pass))
{
    $_SESSION['user'] = $email;
echo 1;
}
    }
    else{
    echo "تم ايقاف حسابك";
    }
}
//// Forget Passwpord
if(isset($_POST["forgetpassword"]) && !isset($error)){
    if( isset($find))
    {
        $rand=rand(10,1000);
        $_SESSION["code_user"]=$rand;
        $_SESSION["temp_email"]=$email;
        if(isset($_SESSION["code_user"]))
         echo 1;

    }

}

//// new pass word
if(isset($_POST["code"]) && !isset($error)){
echo 1;

}
if(isset($_POST["newpass"]) && !isset($error)){
    $db = new Database();
    $passW = $db->Update("UPDATE users SET password=?  WHERE email = ? ",[$password,$_SESSION["temp_email"]]);
    if($passW){
        unset($_SESSION["temp_email"]);
      echo 1;
    }
    else{
        echo "لديك خطاء";
    }
    
    }
    if(isset($_POST["addmin_pass"]) && !isset($error)){
        if($_POST['Confpassword']!=$_POST['password'])
        {
            echo "كلمة السر غير متوافقة  مع تاكيد كلمة السر ";
        }
        else
        {
        $db = new Database();
        $passW = $db->Update("UPDATE admin SET 	password=?  WHERE email = ? ",[$password,$_SESSION["Admin"]]);
        if($passW){
          echo 1;
        }
        else{
            echo "لديك خطاء";
        }
        
        }
    }
    
    if(isset($_POST["user_pass"]) && !isset($error)){
        if($_POST['Confpassword']!=$_POST['password'])
        {
            echo "كلمة السر غير متوافقة  مع تاكيد كلمة السر ";
        }
        else
        {
        $db = new Database();
        $passW = $db->Update("UPDATE users SET 	password=?  WHERE email = ? ",[$password,$_SESSION["user"]]);
        if($passW){
          echo 1;
        }
        else{
            echo "لديك خطاء";
        }
        
        }
    }
    
    
}
?>







