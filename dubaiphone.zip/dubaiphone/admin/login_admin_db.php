<?php
session_start();
require_once "../assets/dataBase/allTabel.php";
$db = new Database;
function sanitize($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
    return $data;
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if(isset($_POST['email'])){
        $email = sanitize($_POST['email']);
    
        
        $cehck_email = $db->GetRow("SELECT email FROM `admin` WHERE email = ? LIMIT 1",[$email]);
        if($cehck_email){      
            $find=1;
        }
        else
        {
            $error = 1;
            echo "الايميل غير موجود<br>";
        }
    
        if(!filter_var($email,FILTER_VALIDATE_EMAIL)){
            echo "<br>هناك خطاء بالايميل";
            $error = 1;
        }
    }

    if(isset($_POST['password'])){

        $password = sanitize($_POST['password']);
        
        if(strlen($password) < 8){
            echo "<br>يجب ان تكون كلمة المرور اكبر من 8 <br>";
            $error = 1;
        }
        else
        {
            $password=md5($password);
                $cehck_password = $db->GetRow("SELECT email,password FROM `admin` WHERE password = ? and email = ? LIMIT 1",[$password,$email]);
                if($cehck_password)
                {
                $pass=1;
                }
                else 
                { $error=1;
                    echo "كلمة السر غير صحيحه";
                }
        }
    }

    if(isset($_POST["login"]) && !isset($error)){
        if( isset($find)  && isset($pass))
        {
            $_SESSION['Admin'] = $email;
        echo 1;
        }
        else
        {
            echo "هناك خطاء بالايميل وكلمة السر  !!!!!";
        }
        }
    }

?>