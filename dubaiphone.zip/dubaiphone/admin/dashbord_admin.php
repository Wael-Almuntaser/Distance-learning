<?php
include "header_admin.php";
?>
  <!-- Header -->
    <style>
    div#bbbbbb {
    padding: 18px 10px;
    background-color: white;
    box-shadow: 6px 9px 9px 26px 5px black;
    margin: 60px auto;
    box-shadow: 5px 1px 4px -1px;
    overflow-x: auto;
}
.KKKKM {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 30px;
}
span
{
    font-weight: bold;
}
</style>
  <header class="w3-container" style="padding-top:22px">
    <h5 style="direction: rtl;"><b><i class="fa fa-dashboard"></i> لوحة القياده</b></h5>
  </header>

  <div class="w3-row-padding w3-margin-bottom" style="direction: rtl;">
    <div class="w3-quarter">
      <div class="w3-container w3-grey w3-padding-16">
        <div class="w3-left"><i class="fa fa-comment w3-xlarge"></i></div>
        <div class="w3-right">
        <?php
             $count_order = $db->getCount("SELECT count(*) from order_client_register");
             $count_order_=$db->getCount("SELECT count(*) from orderr");
             $langage=$db->GetRow("SELECT * from language where Id=1 ");

        ?>
          <h6><?php echo $count_order +$count_order_ ; ?></h6>
        </div>
        <div class="w3-clear"></div>
        <h6>عدد الطلبات</h6>
      </div>
    </div>
    <div class="w3-quarter">
      <div class="w3-container w3-blue w3-text-white w3-padding-16">
        <div class="w3-left"><i class="fa fa-users w3-xlarge"></i></div>
        <div class="w3-right">
        <?php
             $count_user = $db->getCount("SELECT count(*) from users");

        ?>
          <h6><?php echo $count_user ?></h6>
        </div>
        <div class="w3-clear"></div>
        <h6>عدد المستخدمين</h6>
      </div>
    </div>
    <?php
      $money = $db->GetRow("SELECT SUM(price_after) as sum1,SUM(pric_before) as sum  from order_client_register where checkk=1");
      $money_ = $db->GetRow("SELECT SUM(price_after) as sum1,SUM(pric_before) as sum  from orderr where checkk=1");
      $m1=$money['sum1']+$money_['sum1'];
      $m2=$money['sum']+$money_['sum'];
    ?>
    <div class="w3-quarter">
      <div class="w3-container w3-green w3-text-white w3-padding-16">
        <div class="w3-left"><i class="fa fa-money w3-xlarge"></i></div>
        <div class="w3-right">
          <h6><?php echo $m1 ; echo $GLOBALS['langage']["language"] ?> </h6>
        </div>
        <div class="w3-clear"></div>
        <h6>المبلغ قبل الخفيض </h6>
      </div>
    </div>
    <div class="w3-quarter">
      <div class="w3-container w3-red w3-text-white w3-padding-16">
        <div class="w3-left"><i class="fa fa-money w3-xlarge"></i></div>
        <div class="w3-right">
          <h6><?php echo $m2;  echo $GLOBALS['langage']["language"] ?></h6>
        </div>
        <div class="w3-clear"></div>
        <h6>المبلغ بعد التخفيض </h6>
      </div>
    </div>

  </div>
<!--  -->
<section class="ftco-section" style="direction: rtl;">
		<div class="container">
			<div class="row">
				<div class="col-md-12" id="bbbbbb">
					<div class="table-wrap">
						<table class="table table-responsive-xl">
						  <thead>
						    <tr>
						    	<th>&nbsp;</th>
						      <th>الصورة</th>
                  <th>الاسم</th>
                  <th>اجمالي الطلبات</th>
                  <th>اجمالي الطلبات المقبولة</th>
						    </tr>
						  </thead>
						  <tbody id="order_item">
						    <?php
                          $selet_order = $db->GetRows("SELECT DISTINCT(id_order) as order_,tb_name from order_client_register ");
                          

                      
                          foreach($selet_order as $val) 
                          {
                              $count_order_all = $db->getCount("SELECT count($val[order_]) from order_client_register where id_order=$val[order_] ");
                              $count_order_aceept = $db->getCount("SELECT count($val[order_]) from order_client_register where checkk=1 and id_order=$val[order_]");
                              $order_info = $db->GetRow("SELECT path,name from $val[tb_name] where Id =$val[order_] "); 
                              ?>
                      <tr class="alert" role="alert">
                      <td>
                      <label class="checkbox-wrap checkbox-primary">
                      <input type="checkbox" checked>
                      <span class="checkmark"></span>
                      </label>
                      </td>
                      <td class="d-flex align-items-center">
                      <div class="img" style="background-image: url(<?php echo $order_info["path"] ?>);"></div>
                      </td>
                      <td><?php echo $order_info["name"] ?></td>
                      <td><?php echo $count_order_all ?></td>
                      <td><?php echo $count_order_aceept  ?> </td>
                      
                      </tr>
                          <?php
                          }
                ?>
                						    <?php
                          $selet_order = $db->GetRows("SELECT DISTINCT(id_order) as order_n_,tb_name from orderr ");
                          

                      
                          foreach($selet_order as $val) 
                          {
                              $count_order_all = $db->getCount("SELECT count($val[order_n_]) from orderr where id_order=$val[order_n_] ");
                              $count_order_aceept = $db->getCount("SELECT count($val[order_n_]) from orderr where checkk=1 and id_order=$val[order_n_]");
                              $order_info = $db->GetRow("SELECT path,name from $val[tb_name] where Id =$val[order_n_] "); 
                              ?>
                      <tr class="alert" role="alert">
                      <td>
                      <label class="checkbox-wrap checkbox-primary">
                      <input type="checkbox" checked>
                      <span class="checkmark"></span>
                      </label>
                      </td>
                      <td class="d-flex align-items-center">
                      <div class="img" style="background-image: url(<?php echo $order_info["path"] ?>);"></div>
                      </td>
                      <td><?php echo $order_info["name"] ?></td>
                      <td><?php echo $count_order_all ?></td>
                      <td><?php echo $count_order_aceept  ?> </td>
                      
                      </tr>
                          <?php
                          }
                ?>
						  </tbody>
     
						</table>
					</div>
				</div>

			</div>
		</div>
	</section>


<?php
include "footer_admin.php"
?>
</div>

