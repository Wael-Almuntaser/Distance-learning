<?php
require_once "../assets/dataBase/allTabel.php";
$db = new Database();
function sanitize($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
    return $data;
}
$selet = $GLOBALS['db']->GetRow("SELECT * from icon_num limit 1"); 
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

if(isset($_FILES['upload_image']["name"]))
{

if($_FILES['upload_image']["name"]!="")
{  
    $t1=true;

        //    it will be in end  
        $path_Only=basename($_FILES['upload_image']["name"]);
        $path_exp=explode('.',$path_Only);
        $ex=$path_exp[count($path_exp)-1];
        $new_path=round(microtime(true)).'.'.end($path_exp);
        $db_path="";
        if($ex=="jpg" || $ex=="png" || $ex=="jpeg")
        {
            if(is_uploaded_file($_FILES["upload_image"]["tmp_name"]))
            {
    
                 $db_path="../assets/contact/".$new_path;
            }
            else
            {
                echo "لايمكن تحميل الصورهd<br>";
                $error=1;
            }
        }
        else
        {
            echo "فقط JPG, PNG , JPEG<br>";
            $error=1; 
        }

}
else
{$t1=false;}


}
// 
if(isset($_POST['email']))
{
    $email = sanitize($_POST['email']);
    if($email!=$selet["email"])
    {
        $t2=true;
    if(!filter_var($email,FILTER_VALIDATE_EMAIL)){
        echo "<br>خطاء بالايميل";
        $error = 1;
    }
}
else
{
    $t2=false;
}
}
// 

if(isset($_POST['number_']))
{
    $number_ = sanitize($_POST['number_']);
    if($number_!=$selet["number"])
    {
        $t3=true;
        if(strlen($number_) < 6){
            echo "العنوان يب ان يكون اكبر من 6 <br>";
            $error = 1;
        }
    }
    else
    {
        $t3=false;
    }
}

if(isset($_POST['face_con']))
{
    $face_con = sanitize($_POST['face_con']);
    if($face_con!=$selet["face_book"])
    {
        $t4=true;
        if(strlen($face_con) < 6){
            echo "العنوان يب ان يكون اكبر من 6 <br>";
            $error = 1;
        }
    }
    else
    {
        $t4=false;
    }
}
if(isset($_POST['insta_con']))
{
    $insta_con = sanitize($_POST['insta_con']);
    if($insta_con!=$selet["instagram"])
    {
        $t5=true;
        if(strlen($insta_con) < 6){
            echo "العنوان يب ان يكون اكبر من 6 <br>";
            $error = 1;
        }
    }
    else
    {
        $t5=false;
    }
}
if(isset($_POST['whats']))
{
    $whats = sanitize($_POST['whats']);
    if($whats!=$selet["whats"])
    {
        $t5=true;
        if(strlen($whats) < 6){
            echo "العنوان يب ان يكون اكبر من 6 <br>";
            $error = 1;
        }
    }
    else
    {
        $t7=false;
    }
}
if(isset($_POST['twi_con']))
{
    $twi_con = sanitize($_POST['twi_con']);
    if($twi_con!=$selet["tiwiter"])
    {
        $t6=true;
        if(strlen($twi_con) < 6){
            echo "العنوان يب ان يكون اكبر من 6<br>";
            $error = 1;
        }
    }
    else
    {
        $t6=false;
    }
}
if(isset($_POST['sky_con']))
{
    $sky_con = sanitize($_POST['sky_con']);
    if($sky_con!=$selet["sky"])
    {
        $t7=true;
        if(strlen($sky_con) < 6){
            echo "العنوان يب ان يكون اكبر من 6 <br>";
            $error = 1;
        }
    }
    else
    {
        $t7=false;
    }
}










if(!isset($error) )
{
    
    if(!($t1 || $t2 || $t3 || $t4 || $t5 || $t6 || $t7))
    {
        echo "لايوجد تغير";
    }
    else
    {
        if($t1)
        {
            $update=$db->Update("UPDATE icon_num SET number = $number_,email='$email',face_book='$face_con',instagram='$insta_con',whats='$whats',tiwiter='$twi_con',sky='$sky_con',icon='$db_path'   WHERE Id=1 ");
        if($update)
        {
            unlink($selet["icon"]);
            move_uploaded_file($_FILES["upload_image"]["tmp_name"],$db_path);
            echo 1;
        }
        else
        {
            echo "لديك خطاء";
        }
        }
        else
        {
            $update=$db->Update("UPDATE icon_num SET number = $number_,email='$email',face_book='$face_con',instagram='$insta_con',tiwiter='$twi_con',sky='$sky_con'   WHERE Id=1 ");
        if($update)
        {
            echo 1;
        }
        else
        {
            echo "لديك خطاء";
        }
    }
    }
    
}

}
?>