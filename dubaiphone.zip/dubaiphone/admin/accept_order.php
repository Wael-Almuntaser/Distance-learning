<?php
include "header_admin.php";
require_once "../assets/dataBase/allTabel.php";
$db = new Database();
?>
<!doctype html>
<html lang="en">
	<style>
		            #bbb
    {
        background-color: white;
    }
	</style>
	<body>
	<section class="ftco-section" style="direction: rtl;" id="bbb">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="table-wrap">
						<table class="table table-responsive-xl">
						  <thead>
						    <tr>
						    <th>&nbsp;</th>
						      <th>الايميل</th>
						      <th>عدد الطلبات</th>
                              <th>السعر قبل</th>
                              <th>السعر بعد</th>
                              <th>اكثر</th>

						    </tr>
						  </thead>
						  <tbody id="order">
						    
						  </tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</section>


	</body>
</html>

<script src="../assets/js/jquery.js"></script>
<script type="text/javascript">
    $(document).ready(function()
    {  var order_accc="order_accc";
        $.ajax({
            url:"aaa.php",
            data:
            {order_accc:order_accc},
            method:"post",
            success:function(data)
            {
                $("#order").html(data);
            }
        });
        


    });

</script>
</body>
</html>
<?php
include "footer_admin.php"; 
?>
