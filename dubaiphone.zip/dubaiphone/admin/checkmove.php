<?php
$rand=rand(0,10000);
rename("../assets/laptop_img/1.jpg","../assets/hande_img/$rand.jpg");
echo "GOOD";
?>