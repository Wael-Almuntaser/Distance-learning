<?php
include "header_admin.php";
require_once "../assets/dataBase/allTabel.php";
$db = new Database();
?>
<style>
    div#bbbbbb {
    padding: 39px 7px;
    background-color: white;
    box-shadow: 6px 9px 9px 26px 5px black;
    margin: 60px auto;
    box-shadow: 2px 3px 10px -1px;
    overflow-x: auto;
}
.KKKKM {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 30px;
}
span
{
    font-weight: bold;
}
</style>
<!doctype html>
<html lang="en">
	<body>
	<section class="ftco-section" style="direction: rtl;">
		<div class="container">
			<div class="row">
				<div class="col-md-12" id="bbbbbb">
					<div class="table-wrap">
                        <!--  -->
                        <div id="error"  class="alert alert-danger alert-dismissible fade show w-100" role="alert">The order number is bigger than my storage</div>
                        <?php
                        $count="";
                            if(isset($_GET['register']) && $_GET['register']=="1" )
                            {
                                $seletttt = $db->GetRow("SELECT name,Username,email,phone from users where email='$_GET[email]'");
                                $photo= $db->GetRow("SELECT icon from icon_num limit 1");
                               ?>
                            <div class="KKKKM" >
                            <div ><span>:الاسم </span> <span><?php echo $seletttt['name'] ?></span></div><div><span>:الايميل</span><span><?php echo $seletttt['email'] ?></span></div></div>
                            <div class="KKKKM" >
                            <div ><span>:اسم المستخدم </span> <span><?php echo $seletttt['Username'] ?> </span></div><img src="<?php echo $photo["icon"]  ?>" alt="Logo" class="list_img"><div><span>:الرقم  </span><span><?php echo $seletttt['phone'] ?></span></div>
                        </div>
                                <?php
                            }
                        ?>
<?php
if(isset($_GET['register']) && $_GET['register']=="0" )
{
$seletttt = $db->GetRow("SELECT username,email,phone from orderr where email='$_GET[email]' limit 1");
$photo= $db->GetRow("SELECT icon from icon_num limit 1");
?>
<div class="KKKKM" >
<div ><span>:الاسم  </span> <span><?php echo $seletttt['username'] ?></span></div><div><span>Email : </span><span><?php echo $seletttt['email'] ?></span></div></div>
<div class="KKKKM" >
<div ><span>:اسم المستخدم  </span> <span><?php echo $seletttt['username'] ?> </span></div>                        

<img src="<?php echo $photo["icon"]  ?>" alt="Logo" class="list_img">
<div><span>:الرقم </span><span><?php echo $seletttt['phone'] ?></span></div>
</div>
<?php
}
?>

                        
                        <!--  -->
                        
						<table class="table table-responsive-xl">
                        
						  <thead>
						    <tr>
						    	<th>&nbsp;</th>
						      <th>الصوره</th>
                              <th>العدد</th>
                              <th>السعر قبل</th>
                              <th>السعر بعد</th>
                              <th>قبول الطلب</th>
                              <th>حذف</th>

						    </tr>
						  </thead>
						  <tbody id="order_item">
						    
						  </tbody>
     
						</table>
					</div>
				</div>
			</div>
		</div>
	</section>


	</body>
</html>

<script src="../assets/js/jquery.js"></script>
<script type="text/javascript">
    $(document).ready(function()
    {  $("#error").hide();
        var order_item="order_item";
        $.ajax({
            url:"aaa.php ? email=<?php echo $_GET['email'] ?> & tp=<?php echo $_GET['register'] ?>",
            data:
            {order_item:order_item},
            method:"post",
            success:function(data)
            {
                $("#order_item").html(data);
            }
        });
    });
    function Deleting_from_order(e,p)
    {
        var Deleting_order=e;
            var tp=p;
        var order_del="order_del";
        $.ajax({
            url:"aaa.php ? email=<?php echo $_GET['email'] ?> & tp=<?php echo $_GET['register'] ?>",
            data:
            {Deleting_order:Deleting_order,
                tp:tp,
                order_del:order_del,
            },
            method:"post",
            success:function(data)
            {
                $("#order_item").html(data);
            }
        });
    }
    function Accepting_order(e,p,num,num2,tabel,tabel_id)
    {
        var accept_order=e;
            var tp=p;
            var all_num=num;
            var  order_num=num2;
            var tb_name=tabel;
            var tb_id=tabel_id;

        var order_accept="order_del";
        $.ajax({
            url:"aaa.php ? email=<?php echo $_GET['email'] ?> & tp=<?php echo $_GET['register'] ?>",
            data:
            {accept_order:accept_order,
                tp:tp,
                order_accept:order_accept,
                all_num:all_num,
                order_num:order_num,
                tb_name:tb_name,
                tb_id:tb_id,
            },
            method:"post",
            success:function(data)
            {
                $("#order_item").html(data);

            }
        });
    }

// <!-- /////////////////////////////////////////    Update Lock And Not Lock////////////////////// -->

</script>
</body>
</html>
<?php
include "footer_admin.php"; 
?>
