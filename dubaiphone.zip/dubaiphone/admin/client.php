<?php
include "header_admin.php";
?>
<style>
    #bbb
    {
        background-color: white;
    }
</style>
<div class="container mt-5 px-2">
    
    <div class="mb-2 d-flex justify-content-between align-items-center">
        
        <div class="position-relative">
            <span class="position-absolute search"><i class="fa fa-search"></i></span>
            <input class="form-control w-100" placeholder="Search by order#, name..." id="clientSearch">
        </div>
        
        
    </div>
    <div class="table-responsive" style="direction: rtl;" id="bbb">
    <table class="table table-responsive table-borderless">
        
      <thead>
        <tr class="bg-light">
          <th scope="col" width="5%"><input class="form-check-input" type="checkbox"></th>
          <th scope="col" width="5%">#</th>
          <th scope="col" width="20%">اسم المستخدم</th>
          <th scope="col" width="10%">الايميل</th>
          <th scope="col" width="20%">رقم الهاتف</th>
          <th scope="col" width="20%">حظر</th>
          <th scope="col" class="text-end" width="20%"><span>فك الحظر</span></th>
        </tr>
      </thead>
  <tbody id="client">

    
  </tbody>
</table>
  
  </div>
    
</div>


<script src="../assets/js/jquery.js"></script>
<script type="text/javascript">
    $(document).ready(function()
    {  var client="client";
        $.ajax({
            url:"aaa.php",
            data:
            {client:client},
            method:"post",
            success:function(data)
            {
                $("#client").html(data);
            }
        });
        
        $("#clientSearch").keyup(function()
        {
            var input_clent=$(this).val();
            if(input_clent !="")
            {
                $.ajax({
                    url:"aaa.php ",
                    method:"post",
                    data:{input_clent : input_clent},
                    success:function(data)
                    {
                        $("#client").html(data);
                    }
                });
            }
            else
            {
                $.ajax({
            url:"aaa.php",
            data:
            {client:client},
            method:"post",
            success:function(data)
            {
                $("#client").html(data);
            }
        });
            }
        });


    });
/////////////////////////////////////////    Update Lock And Not Lock//////////////////////

    function Unlock(user_id)
        {
            var user_id=user_id;
        $.ajax({
            url:"aaa.php ",
            data:
            {
                user_id:user_id,
            },
            method:"post",
            success:function(data)
            {
                $("#client").html(data);
                if(data="You Have Error")
                {
                    $("#unlock").removeClass("fa fa-lock");
                    $("#lock").addClass("fa fa-unlock");
                }
            }
        }); 
        }


        function lock(user_id_lock)
        {
            var user_id_lock=user_id_lock;
        $.ajax({
            url:"aaa.php ",
            data:
            {
                user_id_lock:user_id_lock,
            },
            method:"post",
            success:function(data)
            {
                $("#client").html(data);
                if(data="You Have Error")
                {
                    $("#lock").removeClass("fa fa-lock");
                    $("#unlock").addClass("fa fa-unlock");
                }
            }
        }); 
        }
</script>
</body>
</html>
<?php
include "footer_admin.php"; 
?>