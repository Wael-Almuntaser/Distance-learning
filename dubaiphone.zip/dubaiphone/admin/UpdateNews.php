<?php
include "header_admin.php";
?>
<style>
    img{
        width: 50px;
    }
</style>
<html>
<body>

</form>
<!-- KKKK TO get show more -->
<section class="trending-product section" style="margin-top: 12px;">
    <div class="container">
        <div class="row" id="searchResult"></div>
    </div>
<div class="Con_num" id="KKKK"></div>
</section>



<!--  -->
<script src="../assets/js/jquery.js"></script>
<script type="text/javascript">
    $(document).ready(function()
    {  var main_news="main_news";
        $.ajax({
            url:"aaa.php ? name=news",
            data:
            {main_news:main_news},
            method:"post",
            success:function(data)
            {
                $("#searchResult").html(data);
            }
        });
        

    });


</script>
</body>
</html>
<?php
include "footer_admin.php"; 
?>