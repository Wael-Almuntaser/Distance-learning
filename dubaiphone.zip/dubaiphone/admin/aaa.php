<?php
require_once "../assets/dataBase/allTabel.php";
$tb="";

if(isset($_GET['name']))
{
    if($_GET['name']=="iphone"){  $tb="iphone_e" ;}
    if($_GET['name']=="samsung"){  $tb="samsung_e";}
    if($_GET['name']=="huawei") { $tb="huawei_e";}
    if($_GET['name']=="hand"){ $tb="hande_e";}
    if($_GET['name']=="laptop"){  $tb="laptop_e";}
    if($_GET['name']=="laptop"){  $tb="laptop_e";}
    if($_GET['name']=="elec"){  $tb="electronic";}
    if($_GET['name']=="watch"){  $tb="watch";}
    $db = new Database();
    $count = $db->getCount("SELECT count(*) from $tb");
}



function GetRowss($str,$end) 
{
    $langage=$GLOBALS['db']->GetRow("SELECT * from language ");
    if($_GET['name']=="elec" ||$_GET['name']=="watch" )
    {
        $selet = $GLOBALS['db']->GetRows("SELECT Id,path,name,price_old,price_new,number_,Discound from $GLOBALS[tb] order by number_ desc limit $str,8 ");   

    }
    else
    {
    $selet = $GLOBALS['db']->GetRows("SELECT Id,path,name,price_old,price_new,memory_,number_,Discound from $GLOBALS[tb] order by number_ desc limit $str,8 ");   
    }
foreach($selet as $val) { 
        if(intval($val["number_"] >0)){
        ?>
        <div class="col-lg-3 col-md-6 col-12">
            <div class="single-product">
                <div class="product-image">
                    <img src="<?php echo $val["path"]?>">
                    <?php if($val["Discound"] >0)
                    {
                        ?>
                            <span class="sale-tag"><?php echo $val["Discound"] ?>  %</span>
                        <?php
                    }
                    ?>
                </div>
                <div class="product-info">
                    <center>
                    <h4 class="title">
                        
                        <a href="#"><?php echo $val["name"]; ?></a>
                        <?php
                        if(!($_GET['name']=="elec" ||$_GET['name']=="watch" ))
                        {
                        ?>
                        <a><?php echo $val["memory_"] ?></a>
                        <?php
                        }
                        ?>
                        
                    </h4>
                    </center>
                    <center>
                    <ul class="review">
                        <li><i class="lni lni-star-filled"></i></li>
                        <li><i class="lni lni-star-filled"></i></li>
                        <li><i class="lni lni-star-filled"></i></li>
                        <li><i class="lni lni-star-filled"></i></li>
                        <li><i class="lni lni-star"></i></li>
                        <li><span>4.0 Review(s)</span></li>
                    </ul>
                    </center>
                    <center>
                    <div class="price">
                        
                        <?php if($val["Discound"] >0)
                    {
                        ?>
                        <span id="AED"><?php echo $val["price_new"]; echo $langage['language'];?> </span>
                        <span class="discount-price"><?php echo $val["price_old"];echo $langage['language']; ?> </span>
                        <?php
                    }
                    else
                    {
                        ?>
                        <span id="AED"><?php echo $val["price_old"];echo $langage['language']; ?> </span>
                        <?php
                    }
                       ?> 
                    </div>
                    <br>
                    <?php if(isset($_POST["deletee"]))
                    { ?>
                        <a class="link" onclick="Deleting_From_tb(<?php echo $val['Id'] ?>,'<?php echo $val['path'] ?>')"><i class='fa fa-remove'></i></a>
                    <?php }
                    else
                    { ?>
                        <a class="link" href="update_element.php?name=<?php echo $GLOBALS['tb'] ?>&id=<?php echo $val['Id']?>"><i class='fa fa-history fa-fw'></i></a>
                    <?php  } ?>
                </center>
                </div>
            </div>
        </div>
        <?php 
                }
            }
           ////////////////
           $num=$GLOBALS['count']/8;
           if($num>1){
            ?>
            <script>
                document.getElementById("KKKK").innerHTML="";
            </script>
            <?php
           for($i=0;$i<$num;$i++) 
           {?>
           <script>
           document.getElementById("KKKK").innerHTML+="<div class='_num' id='next' onclick='GoNext(<?php echo $i ?>)'><?php echo $i ?></div>";
        </script>
       
       <?php
           }
       }
    
}
// show all

if(isset($_POST["main"]))
{
if($count >0 )
{
    GetRowss(0,8);
           /////////////////

}
else
echo "<center><h1>You Do not have Data in tabel $tb </h1></center>";
}

//// end show all
if(isset($_POST["input"]))
{
    $input=$_POST["input"];
    $langage=$GLOBALS['db']->GetRow("SELECT * from language ");
    if($_GET['name']=="elec" ||$_GET['name']=="watch" )
    {
        $selet = $db->GetRows("SELECT Id,path,name,price_old,price_new,number_,Discound from $tb where name like '{$input}%' Or price_old like '{$input}%' Or price_new like '{$input}%'  Or number_ like '{$input}%'"); 

    }
    else
    {
    $selet = $db->GetRows("SELECT Id,path,name,price_old,price_new,memory_,number_,Discound from $tb where name like '{$input}%' Or price_old like '{$input}%' Or price_new like '{$input}%' Or memory_ like '{$input}%' Or number_ like '{$input}%'"); 
    }
    if($count >0)
    { 
        ?>
        <script>
            document.getElementById("KKKK").innerHTML="";
        </script>
        <?php
        if(count($selet)){
        foreach($selet as $val) { 
            if(intval($val["number_"] >0)){
        ?>
        <div class="col-lg-3 col-md-6 col-12">
            <div class="single-product">
                <div class="product-image">
                    <img src="<?php echo $val["path"]?>">
                    <?php if($val["Discound"] >0)
                    {
                        ?>
                            <span class="sale-tag"><?php echo $val["Discound"] ?>  %</span>
                        <?php
                    }
                    ?>
                    
                </div>
                <div class="product-info">
                    <center>
                    <h4 class="title">
                        
                        <a href="#"><?php echo $val["name"] ?></a>
                        <?php
                        if(!($_GET['name']=="elec" ||$_GET['name']=="watch" ))
                        {
                            ?>
                                         <a><?php echo $val["memory_"] ?></a>
                            <?php
                        }
                        ?>
                       
                    </h4>
                    </center>
                    <center>
                    <ul class="review">
                        <li><i class="lni lni-star-filled"></i></li>
                        <li><i class="lni lni-star-filled"></i></li>
                        <li><i class="lni lni-star-filled"></i></li>
                        <li><i class="lni lni-star-filled"></i></li>
                        <li><i class="lni lni-star"></i></li>
                        <li><span>4.0 Review(s)</span></li>
                    </ul>
                    </center>
                    <center>
                    <div class="price">
                        
                        <?php if($val["Discound"] >0)
                    {
                        ?>
                        <span id="AED"><?php echo $val["price_new"];echo $langage['language']; ?> </span>
                        <span class="discount-price"><?php echo $val["price_old"];echo $langage['language']; ?> </span>
                        <?php
                    }
                    else
                    {
                        ?>
                        <span id="AED"><?php echo $val["price_old"];echo $langage['language']; ?> </span>
                        <?php
                    }
                       ?> 
                    </div>
                    <br>
                    <?php if(isset($_POST["deletee"]))
                    { ?>
                        <a class="link" onclick="Deleting_From_tb(<?php echo $val['Id'] ?>,'<?php echo $val['path'] ?>')"><i class='fa fa-remove'></i></a>
                    <?php }
                    else
                    { ?>
                        <a class="link" href="update_element.php?name=<?php echo $GLOBALS['tb'] ?>&id=<?php echo $val['Id']?>"><i class='fa fa-history fa-fw'></i></a>
                    <?php  } ?>
                </center>
                </div>
            </div>
        </div>
                <?php 
                }
            } 
            }
            else
            {
                echo "<center><h1>لايوجد نتائج</h1></center>";
            }
    }
    else
    {
        echo "<center><h1>لايوجد نتائج</h1></center>";
    }
}
if(isset($_POST["next"]))
{
    $start=intval($_POST["next"]);
    $str=($start*8);
    if($start==0) $str=0;
    $end=intval(($start+1)*8);
    GetRowss($str,$end);
}
if(isset($_POST["Deleting_elemt"]))
{
    $id=intval($_POST["Deleting_elemt"]);
    $ddd = $db->GetRow("SELECT id_order FROM `orderr` WHERE id_order = ? LIMIT 1",[$id]);
    if(!$ddd)
    {
    $ddddd = $db->GetRow("SELECT id_order FROM `order_client_register` WHERE id_order = ? LIMIT 1",[$id]);
    if(!$ddddd)
    {
    $del = $db->Delete("DELETE FROM $GLOBALS[tb] WHERE Id=$id");
    unlink($_POST["paa"]);
    GetRowss(0,8);
    }
    else
    {
        ?>
        <script>alert("<?php echo "This Item is order it";  ?>")</script>
        <?php
         GetRowss(0,8);

    }
    }
    else
    {
        ?>
        <script>alert("<?php echo "This Item is order it";  ?>")</script>
        <?php
         GetRowss(0,8);
    }

}

///////////////////////  of client///////////////////////
function Client()
{
    $db = new Database();
    $selet = $db->GetRows("SELECT Id,Username,email,phone from users");
    if(count($selet)){
    foreach($selet as $val) 
    { 
        ?>
        <tr>
    <th scope="row"><input class="form-check-input" type="checkbox"></th>
    <td><?php echo $val["Id"] ?></td>
    <td><?php echo $val["Username"] ?></td>
    <td><?php echo $val["email"] ?></td>
    <td><?php echo $val["phone"] ?></td>
    
    <td><a class="link" onclick='lock(<?php echo $val["Id"] ?>)'><i class=" fa fa-unlock" id="lock"></i></a></td>
    <td class="text-end"><a class="link" onclick="Unlock(<?php echo $val['Id'] ?>)"> <i class="fa fa-lock" id="unlock"></i></a></td>
    </tr>
        <?php 
    }
}
else
{
    ?>
    <h3 class="erer">لايوجد مستخمين في موقعك</h3>
    <?php
}
}
if(isset($_POST["client"]))
{
    Client();
}

if(isset($_POST["input_clent"]))
{
    $input_cl=$_POST["input_clent"];
    $db = new Database();
    $selet = $db->GetRows("SELECT Id,Username,email,phone from users where Username like '{$input_cl}%' Or email like '{$input_cl}%' Or phone like '{$input_cl}%'");
    if(count($selet)){
    foreach($selet as $val) 
    { 
        ?>
        <tr>
    <th scope="row"><input class="form-check-input" type="checkbox"></th>
    <td><?php echo $val["Id"] ?></td>
    <td><?php echo $val["Username"] ?></td>
    <td><?php echo $val["email"] ?></td>
    <td><?php echo $val["phone"] ?></td>
    <td><a class="link" onclick="lock(<?php echo $val['Id'] ?>)"> <i class="fa fa-unlock" id="lock"></i></a></td>
    <td class="text-end"><a class="link" onclick="Unlock(<?php echo $val['Id'] ?>)"> <i class="fa fa-lock"></i></a></td>
    </tr>
        <?php 
    }
}
else
{
    ?>
    <h3 class="erer">لايوجد مستخدمين</h3>
    <?php
}
}
if(isset($_POST["user_id"]))
{
    $db = new Database();
    $id=intval($_POST["user_id"]);
    $passW = $db->Update("UPDATE users SET 	allow=?  WHERE id = ? ",[1,$id]);
    if($passW){
        Client();
    }
    else{
        echo "You Have Error";
    }
}

if(isset($_POST["user_id_lock"]))
{
    $db = new Database();
    $id=intval($_POST["user_id_lock"]);
    $passW = $db->Update("UPDATE users SET 	allow=?  WHERE id = ? ",[0,$id]);
    if($passW){
        Client();
    }
    else{
        echo "لديك خطاء";
    }
}
//////////////////////////////////////// Complete Item/////////////////////////////////////
function Complete($tb_)
{
    $db = new Database();
    $selet = $db->GetRows("SELECT Id,path,name,price_old,Discound,number_ from $tb_ where number_<=0");
    if(count($selet)){
    foreach($selet as $val) 
    { 
        ?>
<tr class="alert" role="alert">
<td>
<label class="checkbox-wrap checkbox-primary">
<input type="checkbox" checked>
<span class="checkmark"></span>
</label>
</td>
<td class="d-flex align-items-center">
<div class="img" style="background-image: url(<?php echo $val["path"] ?>);"></div>
<div class="pl-3 email">
    <span>Price :<?php echo $val["price_old"]  ?></span>
</div>
</td>
<td><?php echo $val["name"]  ?></td>
<td class="status"><span class="active"><?php echo $val["Discound"]  ?></span></td>

<td><a class="link" href="update_element.php?name=<?php echo $tb_ ?>&id=<?php echo $val['Id']?>" ><i class="fa fa-plus fa-fw" id="lock"></i></a></td>
<td><a class="link" onclick="Deleting_from_compelet(<?php echo $val['Id']?>,'<?php echo $val['path'] ?>','<?php echo $tb_ ?>')"><i class="fa fa-trash-o" id="unlock"></i></a></td>

</tr>
        <?php 
    }
}
}
if(isset($_POST["complete"]))
{
    Complete("iphone_e");
    Complete("samsung_e");
    Complete("huawei_e");
    Complete("hande_e");
    Complete("laptop_e");
}
function searchh($tbb__,$ind)
{

    $db = new Database();
    $selet = $db->GetRows("SELECT Id,path,name,price_old,Discound,number_ from $tbb__ where number_ <=0 and ( name like '{$ind}%' Or price_old like '{$ind}%' Or Discound like '{$ind}%' )");
    if(count($selet)){
    foreach($selet as $val) 
    { 
        ?>
<tr class="alert" role="alert">
<td>
<label class="checkbox-wrap checkbox-primary">
<input type="checkbox" checked>
<span class="checkmark"></span>
</label>
</td>
<td class="d-flex align-items-center">
<div class="img" style="background-image: url(<?php echo $val["path"] ?>);"></div>
<div class="pl-3 email">
    <span>Price :<?php echo $val["price_old"]  ?></span>
</div>
</td>
<td><?php echo $val["name"]  ?></td>
<td class="status"><span class="active"><?php echo $val["Discound"]  ?></span></td>
<td><a class="link" href="Adding_compelet.php?tbnamp=<?php echo $tbb__ ?>&id=<?php echo $val['Id']?>&path=<?php echo $val['path'] ?> "><i class="fa fa-plus fa-fw" id="lock"></i></a></td>
<td><a class="link" onclick="Deleting_from_compelet(<?php echo $val['Id']?>,'<?php echo $val['path'] ?>','<?php echo $tbb__ ?>')"><i class="fa fa-trash-o" id="unlock"></i></a></td>

</tr>
        <?php 
    }
}
}
if(isset($_POST["input_clent_complete"]))
{
    $input_cl=$_POST["input_clent_complete"];
    searchh("iphone_e",$input_cl);
    searchh("samsung_e",$input_cl);
    searchh("huawei_e",$input_cl);
    searchh("hande_e",$input_cl);
    searchh("laptop_e",$input_cl);
}
if(isset($_POST["deleteee"]))
{
    $db = new Database();
    $id=intval($_POST["Deleting_elemtt"]);
    $ddd = $db->GetRow("SELECT id_order FROM `orderr` WHERE id_order = ? LIMIT 1",[$id]);
    if(!$ddd)
    {
    $ddddd = $db->GetRow("SELECT id_order FROM `order_client_register` WHERE id_order = ? LIMIT 1",[$id]);
    if(!$ddddd)
    {
    $del = $db->Delete("DELETE FROM $_POST[tp_namee] WHERE Id=$id");
    unlink($_POST["pat"]);
    Complete("iphone_e");Complete("samsung_e"); Complete("huawei_e"); Complete("hande_e"); Complete("laptop_e");
    }
    else
    {
        Complete("iphone_e");Complete("samsung_e"); Complete("huawei_e"); Complete("hande_e"); Complete("laptop_e");
        ?>
        <script>alert( "هذا الصنف علية طلبات")</script>
        <?php
   

    }
    }
    else
    {
        Complete("iphone_e");Complete("samsung_e"); Complete("huawei_e"); Complete("hande_e"); Complete("laptop_e");
        ?>
        <script>alert("<?php echo "هذا الصنف علية طلبات";  ?>")</script>
        <?php
         
    }

}
//////////////////////////////////////////Order//////////////////////////////////////
function Order()
{
    $db = new Database();
    $selet = $db->GetRows("SELECT DISTINCT(email_user) from order_client_register where checkk=0 and sure=1");
    if(count($selet)){
    foreach($selet as $val) 
    { 
        $seletttt = $db->GetRow("SELECT SUM(price_after) as sum1,SUM(pric_before) as sum ,COUNT(email_user) as con from order_client_register where email_user='$val[email_user]' and  checkk=0  and sure=1");
        ?>
<tr class="alert" role="alert">
<td>
<label class="checkbox-wrap checkbox-primary">
<input type="checkbox" checked>
<span class="checkmark"></span>
</label>
</td>
<td><?php echo $val["email_user"]  ?></td>
<td><?php echo $seletttt['con']  ?></td>
<td><?php echo $seletttt['sum1']  ?></td>
<td><?php echo $seletttt['sum']  ?></td>
<td><a class="link" href="detail_order.php?email=<?php echo $val["email_user"]   ?>&register=1" ><i class="fa fa-info-circle" id="unlock"></i></a></td>

</tr>
        <?php 
}
}
$selett = $db->GetRows("SELECT DISTINCT(email) from orderr where checkk=0 and sure=1");
if(count($selett)){
foreach($selett as $vall) 
{ 
    $seleted = $db->GetRow("SELECT SUM(price_after) as sum1,SUM(pric_before) as sum ,COUNT(email) as con from orderr where email='$vall[email]' and  checkk=0 and sure=1");
    ?>
    <tr class="alert" role="alert">
    <td>
    <label class="checkbox-wrap checkbox-primary">
    <input type="checkbox" checked>
    <span class="checkmark"></span>
    </label>
    </td>
    <td><?php echo $vall["email"]  ?></td> 
    <td><?php echo $seleted['con']  ?></td>
    <td><?php echo $seleted['sum1']  ?></td>
    <td><?php echo $seleted['sum']  ?></td>
    <td><a class="link" href="detail_order.php?email=<?php echo $vall["email"]   ?>&register=0"><i class="fa fa-info-circle" id="unlock"></i></a></td>
    
    </tr>
            <?php 

}
}
}
if(isset($_POST["order"]))
{
    Order();
}

///////////////////////////////////////////Order Item//////////////////////////////////////////
function Orderrr()
{
    $db = new Database();
    if($_GET["tp"]=="1")
    {
        $selet_order = $db->GetRows("SELECT * from order_client_register where email_user='$_GET[email]' and  checkk=0 and sure=1");
        $Max_Min = $db->GetRow("SELECT SUM(price_after) as sum1,SUM(pric_before) as sum  from order_client_register where email_user='$_GET[email]' and  checkk=0 and sure=1");
    }
    if($_GET["tp"]=="0")
    {
        $selet_order = $db->GetRows("SELECT * from orderr where email='$_GET[email]' and  checkk=0 and sure=1");
        $Max_Min = $db->GetRow("SELECT SUM(price_after) as sum1,SUM(pric_before) as sum  from orderr where email='$_GET[email]' and  checkk=0 and sure=1");
    }
    
        foreach($selet_order as $val) 
        {
            $order_info = $db->GetRow("SELECT Id,path,name,price_old,price_new,number_ from $val[tb_name] where Id =$val[id_order] "); 
            ?>
    <tr class="alert" role="alert">
    <td>
    <label class="checkbox-wrap checkbox-primary">
    <input type="checkbox" checked>
    <span class="checkmark"></span>
    </label>
    </td>
    <td class="d-flex align-items-center">
    <div class="img" style="background-image: url(<?php echo $order_info["path"] ?>);"></div>
    <div class="pl-3 email">
    <span>Name :<?php echo $order_info["name"] ?></span>
    </div>
    </td>
    <td><?php echo $val["count"]  ?></td>
    <td><?php echo($val['price_after']) ?></td>
    <td><?php echo($val['pric_before']) ?> </td>
    <td><a class="link" onclick="Accepting_order(<?php echo $val['Id']?>,'<?php echo $_GET['tp'] ?>',<?php echo $order_info['number_'] ?>,<?php echo $val['count'] ?>,'<?php echo $val['tb_name']  ?>',<?php echo $order_info['Id'] ?>)"><i class="fa fa-exclamation-circle" id="unlock"></i> Accept</a></td>
    <td><a class="link" onclick="Deleting_from_order(<?php echo $val['Id']?>,'<?php echo $_GET['tp'] ?>')"><i class="fa fa-trash-o" id="unlock"></i></a></td>
    
    </tr>
        <?php
        }
        ?>
        <tr  style="box-shadow: 2px 3px 10px -1px;">
        <td colspan="3" >Total</td>
        <td ><?php echo $Max_Min['sum1'] ?></td>
        <td ><?php echo $Max_Min['sum'] ?></td>
        </tr>
        <?php
}
if(isset($_POST["order_item"]))
{
    Orderrr();
    
}
if(isset($_POST['order_del']))
{

    $db = new Database();
    $id=intval($_POST["Deleting_order"]);
    if($_POST['tp']=="1")
    {
        $del = $db->Delete("DELETE FROM order_client_register WHERE Id=$id");
    }
    else
    {
        $del = $db->Delete("DELETE FROM orderr WHERE Id=$id");
    }
    Orderrr();
}

if(isset($_POST['order_accept']))
{
    $db = new Database();
if(intval($_POST['order_num']) <= intval($_POST['all_num']))
{
    $id=intval($_POST["accept_order"]);
    if($_POST['tp']=="1")
    {
        $passW = $db->Update("UPDATE order_client_register SET 	checkk=?  WHERE Id = ? ",[1,$id]);
    }
    else
    {
        $passW = $db->Update("UPDATE orderr SET checkk=?  WHERE Id = ? ",[1,$id]);
    }
    $new_numm=$_POST['all_num']-$_POST['order_num'];

    $passWw = $db->Update("UPDATE $_POST[tb_name] SET 	number_=?  WHERE Id = ? ",[$new_numm,intval($_POST['tb_id'])]);

    Orderrr();
}
else
{
    Orderrr();
    ?>
    <script>document.getElementById("error").style.display="block"</script>
    <?php
}


}
////////////////////////////////////////////////Accept Order////////////////////////////
function Accept_order__()
{
    $db = new Database();
    $selet = $db->GetRows("SELECT DISTINCT(email_user) from order_client_register where checkk=1 and sure=1");
    if(count($selet)){
    foreach($selet as $val) 
    { 
        $seletttt = $db->GetRow("SELECT SUM(price_after) as sum1,SUM(pric_before) as sum ,COUNT(email_user) as con from order_client_register where email_user='$val[email_user]' and  checkk=1 and sure=1");
        ?>
<tr class="alert" role="alert">
<td>
<label class="checkbox-wrap checkbox-primary">
<input type="checkbox" checked>
<span class="checkmark"></span>
</label>
</td>
<td><?php echo $val["email_user"]  ?></td>
<td><?php echo $seletttt['con']  ?></td>
<td><?php echo $seletttt['sum1']  ?></td>
<td><?php echo $seletttt['sum']  ?></td>
<td><a class="link" href="accept_detail_p.php?email=<?php echo $val["email_user"]   ?>&register=1"  ><i class="fa fa-info-circle" id="unlock"></i></a></td>

</tr>
        <?php 
}
}
$selett = $db->GetRows("SELECT DISTINCT(email) from orderr where checkk=1 and sure=1");
if(count($selett)){
foreach($selett as $vall) 
{ 
    $seleted = $db->GetRow("SELECT SUM(price_after) as sum1,SUM(pric_before) as sum ,COUNT(email) as con from orderr where email='$vall[email]' and  checkk=1 and sure=1 ");
    ?>
    <tr class="alert" role="alert">
    <td>
    <label class="checkbox-wrap checkbox-primary">
    <input type="checkbox" checked>
    <span class="checkmark"></span>
    </label>
    </td>
    <td><?php echo $vall["email"]  ?></td>
    <td><?php echo $seleted['con']  ?></td>
    <td><?php echo $seleted['sum1']  ?></td>
    <td><?php echo $seleted['sum']  ?></td>
    <td><a class="link" href="accept_detail_p.php?email=<?php echo $vall["email"] ?>&register=0"  ><i class="fa fa-info-circle" id="unlock"></i></a></td>
    
    </tr>
            <?php 

}
}
}
if(isset($_POST['order_accc']))
{
    Accept_order__();
}

function Orderrr_accpet()
{
    $db = new Database();
    if($_GET["tp"]=="1")
    {
        $selet_order = $db->GetRows("SELECT * from order_client_register where email_user='$_GET[email]' and checkk=1 and sure=1");
        $Max_Min = $db->GetRow("SELECT SUM(price_after) as sum1,SUM(pric_before) as sum  from order_client_register where email_user='$_GET[email]' and checkk=1 and sure=1");
    }
    if($_GET["tp"]=="0")
    {
        $selet_order = $db->GetRows("SELECT * from orderr where email='$_GET[email]' and checkk=1 and sure=1");
        $Max_Min = $db->GetRow("SELECT SUM(price_after) as sum1,SUM(pric_before) as sum  from orderr where email='$_GET[email]' and checkk=1 and sure=1");
    }
    
        foreach($selet_order as $val) 
        {
            $order_info = $db->GetRow("SELECT Id,path,name,price_old,price_new,number_ from $val[tb_name] where Id =$val[id_order] "); 
            ?>
    <tr class="alert" role="alert">
    <td>
    <label class="checkbox-wrap checkbox-primary">
    <input type="checkbox" checked>
    <span class="checkmark"></span>
    </label>
    </td>
    <td class="d-flex align-items-center">
    <div class="img" style="background-image: url(<?php echo $order_info["path"] ?>);"></div>
    <div class="pl-3 email">
    <span>Name :<?php echo $order_info["name"] ?></span>
    </div>
    </td>
    <td><?php echo $val["count"]  ?></td>
    <td><?php echo($val['price_after'])  ?></td>
    <td><?php echo $val['pric_before'] ?> </td>
    <td><a class="link" onclick="Deleting_from_order(<?php echo $val['Id']?>,'<?php echo $_GET['tp'] ?>')"><i class="fa fa-trash-o" id="unlock"></i></a></td>
    
    </tr>
        <?php
        }
        ?>
        <tr  style="box-shadow: 2px 3px 10px -1px;">
        <td colspan="3" >Total</td>
        <td ><?php echo $Max_Min['sum1'] ?></td>
        <td ><?php echo $Max_Min['sum'] ?></td>
        </tr>
        <?php
}
if(isset($_POST['accept_order_itemmmm']))
{
    Orderrr_accpet();
}
if(isset($_POST['order_del_accpet']))
{

    $db = new Database();
    $id=intval($_POST["Deleting_order"]);
    if($_POST['tp']=="1")
    {
        $del = $db->Delete("DELETE FROM order_client_register WHERE Id=$id");
    }
    else
    {
        $del = $db->Delete("DELETE FROM orderr WHERE Id=$id");
    }
    Orderrr_accpet();
}
//////////////////////////uuuuuuuuuu///////////////////////////

function Unsuree($tbbbb_)
{
    if($tbbbb_=="orderr") $r_n=0;
    else $r_n=1;
    $db = new Database();

        $selet_order = $db->GetRows("SELECT * from $tbbbb_ where  sure=0");

    
        foreach($selet_order as $val) 
        {
            $order_info = $db->GetRow("SELECT Id,path,name,price_old,price_new,number_ from $val[tb_name] where Id =$val[id_order] "); 
            ?>
    <tr class="alert" role="alert">
    <td>
    <label class="checkbox-wrap checkbox-primary">
    <input type="checkbox" checked>
    <span class="checkmark"></span>
    </label>
    </td>
    <td class="d-flex align-items-center">
    <div class="img" style="background-image: url(<?php echo $order_info["path"] ?>);"></div>
    <div class="pl-3 email">
    <span>Name :<?php echo $order_info["name"] ?></span>
    </div>
    </td>
    <td><?php echo $val["count"]  ?></td>
    <td><?php echo($val['price_after'])  ?></td>
    <td><?php echo $val['pric_before'] ?> </td>
    <td><a class="link" onclick="Deleting_Unsure(<?php echo $val['Id']?>,'<?php echo $val['tb_name'] ?>',<?php echo $r_n ?>)"><i class="fa fa-trash-o" id="unlock"></i></a></td>
    
    </tr>
        <?php
        }
}

if(isset($_POST['unsure']))
{
    Unsuree("orderr");
    Unsuree("order_client_register"); 
}

if(isset($_POST['order_del_unsure']))
{

    $db = new Database();
    $id=intval($_POST["Deleting_order"]);
    if($_POST['tyyyyyy']==1)
    {
        $del = $db->Delete("DELETE FROM order_client_register WHERE Id=$id");
    }
    else
    {
        $del = $db->Delete("DELETE FROM orderr WHERE Id=$id");
    }
    Unsuree("orderr");
    Unsuree("order_client_register"); 
}

//////////////////////////////UPdate News///////////////////////////////////
function UpdateNews() 
{
    $selet = $GLOBALS['db']->GetRows("SELECT Id,photo,header_1,header_2,price from $GLOBALS[tb]  ");
    foreach($selet as $val) { 
        ?>
        <div class="col-lg-3 col-md-6 col-12">
            <div class="single-product">
                <div class="product-image">
                    <img src="<?php echo $val["photo"]?>">
                </div>
                <div class="product-info">
                    <center>
                    <h4 class="title">
                        
                        <a href="#"><?php echo $val["header_2"]; ?></a>
                    </h4>
                    </center>
                    <center>
                    <div class="price">
                        <span id="AED"><?php echo $val["price"]?> $</span>
                    </div>
                    <br>
                    <?php if(isset($_POST["deleteNews"]))
                    { ?>
                        <a class="link" onclick="Deleting_From_New(<?php echo $val['Id'] ?>,'<?php echo $val['photo'] ?>')"><i class='fa fa-remove'></i></a>
                    <?php }
                    else
                    { ?>
                        <a class="link" href="update_element_new.php?name=<?php echo $GLOBALS['tb'] ?>&id=<?php echo $val['Id']?>"><i class='fa fa-history fa-fw'></i></a>
                    <?php  } ?>
                </center>
                </div>
            </div>
        </div>
        <?php 
                
            }
           ////////////////
    
}
// show all

if(isset($_POST["main_news"]))
{
if($count >0 )
{
    UpdateNews();
}
else
{
    echo "لا شي";
}
}
// ///////////////delete News ////////////////deleteNews   deletee Deleting_elemt
if(isset($_POST["Deleting_elemt_news"]))
{
    $id=intval($_POST["Deleting_elemt_news"]);


    $del = $db->Delete("DELETE FROM $GLOBALS[tb] WHERE Id=$id");
    unlink($_POST["paa"]);
    UpdateNews();


}

if(isset($_POST['language']))
{
    $db = new Database();
    $passW = $db->Update("UPDATE language SET 	language=?  WHERE id = ? ",[$_POST['zise'],1]);
    echo 1;
}

?>