<?php
include "header_admin.php";
require_once "../assets/dataBase/allTabel.php";
$db = new Database();
?>
<!doctype html>
<html lang="en">
    <style>
                    #bbb
    {
        background-color: white;
    }
    </style>
	<body>
	<section class="ftco-section" style="direction: rtl;" id="bbb">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="table-wrap">
						<table class="table table-responsive-xl">
                        <div class="position-relative">
            <span class="position-absolute search"><i class="fa fa-search"></i></span>
            <input class="form-control w-100" placeholder="Search by order#, name..." id="clientSearch">
        </div>
						  <thead>
						    <tr>
						    	<th>&nbsp;</th>
						    	<th>الصورة</th>
						      <th>الاسم</th>
						      <th>التخفيض</th>
                              <th>تعديل</th>
                              <th>حذف</th>
						    </tr>
						  </thead>
						  <tbody id="complete">
						    
						  </tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</section>


	</body>
</html>

<script src="../assets/js/jquery.js"></script>
<script type="text/javascript">
    $(document).ready(function()
    {  var complete="complete";
        $.ajax({
            url:"aaa.php",
            data:
            {complete:complete},
            method:"post",
            success:function(data)
            {
                $("#complete").html(data);
            }
        });
        
        $("#clientSearch").keyup(function()
        {
            var input_clent_complete=$(this).val();
            if(input_clent_complete !="")
            {
                $.ajax({
                    url:"aaa.php ",
                    method:"post",
                    data:{input_clent_complete : input_clent_complete},
                    success:function(data)
                    {
                        $("#complete").html(data);
                    }
                });
            }
            else
            {
                $.ajax({
            url:"aaa.php",
            data:
            {complete:complete},
            method:"post",
            success:function(data)
            {
                $("#complete").html(data);
            }
        });
            }
        });


    });
    function Deleting_from_compelet(e,p,tb_name)
    {
        var Deleting_elemtt=e;
            var pat=p;
        var deleteee="deleteee";
        tp_namee=tb_name;
        $.ajax({
            url:"aaa.php",
            data:
            {Deleting_elemtt:Deleting_elemtt,
                pat:pat,
                deleteee:deleteee,
                tp_namee:tp_namee,
            },
            method:"post",
            success:function(data)
            {
                $("#complete").html(data);
            }
        });
    }
/////////////////////////////////////////    Update Lock And Not Lock//////////////////////

</script>
</body>
</html>
<?php
include "footer_admin.php"; 
?>
