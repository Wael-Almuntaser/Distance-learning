<?php
include "header_admin.php";
require_once "../assets/dataBase/allTabel.php";
$db = new Database();
?>
<style>
    div#bbbbbb {
    padding: 39px 7px;
    background-color: white;
    box-shadow: 6px 9px 9px 26px 5px black;
    margin: 60px auto;
    box-shadow: 2px 3px 10px -1px;
    overflow-x: auto;
}
.KKKKM {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 30px;
}
span
{
    font-weight: bold;
}
</style>
<!doctype html>
<html lang="en">
	<body>
	<section class="ftco-section" style="direction: rtl;">
		<div class="container">
			<div class="row">
				<div class="col-md-12" id="bbbbbb" >
					<div class="table-wrap" id="pdf">
                        <!--  -->
                        <div id="error"  class="alert alert-danger alert-dismissible fade show w-100" role="alert">The order number is bigger than my storage</div>
                        <?php
                        $count="";
                            if(isset($_GET['register']) && $_GET['register']=="1" )
                            {
                                $seletttt = $db->GetRow("SELECT name,Username,email,phone from users where email='$_GET[email]'");
                                $photo= $db->GetRow("SELECT icon from icon_num limit 1");
                                ?>
                            <div class="KKKKM"  >
                            <div ><span>:الاسم </span> <span><?php echo $seletttt['name'] ?></span></div><div><span>:الايميل</span><span><?php echo $seletttt['email'] ?></span></div></div>
                            <div class="KKKKM" >
                            <div ><span>:اسم المستخدم </span> <span><?php echo $seletttt['Username'] ?> </span></div><img src="<?php echo $photo["icon"]  ?>" alt="Logo" class="list_img"><div><span>:الرقم</span><span><?php echo $seletttt['phone'] ?></span></div>
                        </div>
                                <?php
                            }
                        ?> 
<?php
if(isset($_GET['register']) && $_GET['register']=="0" )
{
$seletttt = $db->GetRow("SELECT username,email,phone from orderr where email='$_GET[email]' limit 1");
$photo= $db->GetRow("SELECT icon from icon_num limit 1");
?>
<div class="KKKKM" >
<div ><span>:الاسم </span> <span><?php echo $seletttt['username'] ?></span></div><div><span>:الايميل  </span><span><?php echo $seletttt['email'] ?></span></div></div>
<div class="KKKKM" >
<div ><span>:اسم المستخدم </span> <span><?php echo $seletttt['username'] ?> </span></div><img src="<?php echo $photo["icon"]  ?>" alt="Logo" class="list_img"><div><span>:الرقم</span><span><?php echo $seletttt['phone'] ?></span></div>
</div>
<?php
}
?>

                        
                        <!--  -->
                        
						<table class="table table-responsive-xl">
                        
						  <thead>
						    <tr>
						    	<th>&nbsp;</th>
						      <th>الصورة</th>
                              <th>الرقم</th>
                              <th>السعر قبل</th>
                              <th>السعر بعد</th>
                              <th>حذف</th>

						    </tr>
						  </thead>
						  <tbody id="order_item">
						    
						  </tbody>
     
						</table>
					</div> 
<!-- 1 -->
<!--  -->
                    <div class="detailll">
                        <a onclick="printt()"><i class="fa fa-print"></i><p>فاتورة</p> </a>
                        <div><i class="fa fa-print"></i> <p>سند قبض </p></div>
                        <div><i class="fa fa-print"></i><p>طلب تقسيط </p></div>
                        <div><i class="fa fa-print"></i><p>شحن ارامكس </p></div>
                    </div>
                    <!--  -->
				</div>

			</div>
		</div>
	</section>


	</body>
</html>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js" integrity="sha512-GsLlZN/3F2ErC5ifS5QtgpiJtWd43JWSuIgh7mbzZ8zBps+dvLusV+eNQATqgA/HdeKFVgA5v3S/cIrLF7QnIg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<script>
function printt()
{
    let p=document.getElementById("pdf");
    // html2pdf().from().save(p);
    html2pdf(element);
}
</script>
<script src="../assets/js/jquery.js"></script>
<script type="text/javascript">
    $(document).ready(function()
    {  $("#error").hide(); 
        var accept_order_itemmmm="accept_order_itemmmm";
        $.ajax({
            url:"aaa.php ? email=<?php echo $_GET['email'] ?> & tp=<?php echo $_GET['register'] ?>",
            data:
            {accept_order_itemmmm:accept_order_itemmmm},
            method:"post",
            success:function(data)
            {
                $("#order_item").html(data);
            }
        });
    });
    function Deleting_from_order(e,p)
    {
        var Deleting_order=e;
            var tp=p;
        var order_del_accpet="order_del_accpet";
        $.ajax({
            url:"aaa.php ? email=<?php echo $_GET['email'] ?> & tp=<?php echo $_GET['register'] ?>",
            data:
            {Deleting_order:Deleting_order,
                tp:tp,
                order_del_accpet:order_del_accpet,
            },
            method:"post",
            success:function(data)
            {
                $("#order_item").html(data);
            }
        });
    }


// <!-- /////////////////////////////////////////    Update Lock And Not Lock////////////////////// -->


</script>
</body>
</html>
<?php
include "footer_admin.php"; 
?>
