<head>
<link rel="stylesheet" href="../assets/css/bootstrap.min.css" />
    <link rel="stylesheet" href="../assets/css/LineIcons.3.0.css" />
    <link rel="stylesheet" href="../assets/css/tiny-slider.css" />
    <link rel="stylesheet" href="../assets/css/glightbox.min.css" />
    <link rel="stylesheet" href="../assets/css/main.css" />
    <link rel="stylesheet" href="../assets/css/login_and_register.css" />
    <script src="../assets/js/jquery.js"></script>
</head>
  <div class="container_R" id="container_l">
  <div id="error" class="alert alert-danger alert-dismissible fade show w-100" role="alert"></div>
    <div class="forms">
        <div class="form-content">
          <div class="login-form">
            <div class="title">تسجيل الادمن</div>
          <form action="#" id="sample_form" method="post">
          <div class="user-details">
                <div class="input-boxx">
                    <span class="details">الايميل</span>
                    <input type="email" placeholder="إدخل الايميل" id="email" name="email">
                  </div>
                  <div class="input-boxx">
                    <span class="details">كلمة السر</span>
                    <input type="password" placeholder="إدخل كلمة السر" id="password" name="password" >
                  </div>
                  <input type="hidden" id="login" name="login" value="login">
              <!-- <div class="text"><a href="#">نسيت كلمة السر?</a></div> -->
              <div class="button">
                <input type="submit" id="submit" name="submit" value="تسجيل">
              </div>
</div>
        </form>
        <div class="preloader-inner" id="preloader_1">
          <div class="preloader-icon">
              <span></span>
              <span></span>
          </div>
      </div>
      </div>
    </div>
    </div>
  </div>

<script>
  $(document).ready(function(){
    $("#preloader_1").hide();
    $("#error").hide();
    $('#sample_form').on('submit', function(event){
      event.preventDefault();
        $.ajax({
          url : "login_admin_db.php",
          method:"POST",
          data: new FormData(this),
          contentType:false,
          cache:false,
          processData:false,
          success: function(response){
            if(response == 1){
              $("#preloader_1").show();
              $("#error").removeClass("alert-danger");
              $("#error").addClass("alert-primary");
              $("#error").show().html("تم تسجيل الدخول بنجاح");
              setInterval(function () {
             window.location = "dashbord_admin.php";
              }, 2000);
           
               
            }
            else{
             $("#error").show().html(response);
            }
					}
        })  
    
      
        return false;
    })
  })

</script>