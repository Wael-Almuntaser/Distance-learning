<?php
session_start();
require_once "../assets/dataBase/allTabel.php";
include "../home/array_card.php";

$newpath="";
$tb="";
function sanitize($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
    return $data;
}
if(isset($_GET['name']))
{

    if($_GET['name']=="iphone"){ $newpath="iphone_img"; $tb="iphone_e" ;}
    if($_GET['name']=="samsung"){ $newpath="samsung_img"; $tb="samsung_e";}
    if($_GET['name']=="huawei") {$newpath="huawei_img"; $tb="huawei_e";}
    if($_GET['name']=="hand"){ $newpath="hande_img"; $tb="hande_e";}
    if($_GET['name']=="laptop"){ $newpath="laptop_img"; $tb="laptop_e";}
    if($_GET['name']=="news"){ $newpath="news1";}
    if($_GET['name']=="elec"){ $newpath="elec_img"; $tb="electronic";}
    if($_GET['name']=="watch"){ $newpath="watch_img"; $tb="watch";}
    

}
else
{
    if(isset($_GET['folder']))
    {
        $newpath=$_GET['folder'];
    }
    elseif(isset($_POST["buy"]))
    {
        $ttttt=1;
    }
    else
    {
    echo "اختر مسار الملف";
    $error=1;
    }
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if(isset($_POST['email'])){
        $email = sanitize($_POST['email']);
    
        if(!filter_var($email,FILTER_VALIDATE_EMAIL)){
            echo "<br>ضيغة الايميل غير صحيحة<br>";
            $error = 1;
        }
    }

if(isset($_FILES['upload_image']["name"]))
{
if($_FILES['upload_image']["name"]!="")
{  
    $path_Only=basename($_FILES['upload_image']["name"]);
    $path_exp=explode('.',$path_Only);
    $ex=$path_exp[count($path_exp)-1];
    $new_path=round(microtime(true)).'.'.end($path_exp);
    $db_path="";
    if($ex=="jpg" || $ex=="png" || $ex=="jpeg")
    {
        if(is_uploaded_file($_FILES["upload_image"]["tmp_name"]))
        {

             $db_path="../assets/$newpath/".$new_path;
        }
        else
        {
            echo "لايمكن تحميل الصورة<br>";
            $error=1;
        }
    }
    else
    {
        echo "فقط JPG, PNG , JPEG<br>";
        $error=1; 
    }
}
else
{
    echo "اختر الصورة اولا<br>";
    $error=1;
}
}
if(isset($_POST['name'])){
    $name = sanitize($_POST['name']);
    if(strlen($name) < 6){
        echo "الاسم يجب ان يكون اكبر من 6 احرف <br>";
        $error = 1;
    }
}
if(isset($_POST['title'])){
    $title = sanitize($_POST['title']);
    if(strlen($title) < 6){
        echo "العنوان يجب ان يكون اكبر من 6 احرف  <br>";
        $error = 1;
    }
}
if(isset($_POST['Price'])){
    $Price = sanitize($_POST['Price']);
    $Price=intval($Price);
    if(strlen($Price) < 1){
        echo "السعر يجب ان يكون اكبر من 6 احرف  <br>";
        $error = 1;
    }
}
if(isset($_POST['zise'])){
    $zise = sanitize($_POST['zise']);
    if(strlen($zise) < 1){
        echo "ادخل الكمية المتاحة <br>";
        $error = 1;
    }
}
if(isset($_POST['number_'])){
    $number_ = sanitize($_POST['number_']);
    if(intval($number_) <=0){
        echo "ادخل الكمية المتاحة   <br>";
        $error = 1;
}
}
if(isset($_POST['detial'])){
    $detial = sanitize($_POST['detial']);
    if($detial>0)
    {
        if(strlen($detial) <7)
        {
            echo "اخل العنوان الخاص بك";
            $error=1;
        }
    }
    else{
        echo "العنوان مطلوب<br>";
        $error=1;
    }
}
if(isset($_POST['phone'])){
    $phone = sanitize($_POST['phone']);
    if($phone >0){
    if(strlen($phone) <7){
        echo "الرقم يجب ان يكون اكبر من 7 <br>";
        $error = 1;
    }
}
else
{
    echo "الرقم مطلوب";
    $error=1;
}
}
if(isset($_POST['Discond'])){
    $Discond = sanitize($_POST['Discond']);
    $Discond=intval($Discond);
    if($Discond==0) $new_price=0;
    else
    {
        $new_price=$Price - $Price*($Discond/100);
    }
    if(strlen($Discond) < 1){
        echo "التخفيص مهم اذا لم يوحد اضغط 0  <br>";
        $error = 1;
    }
}
if(isset($_POST['Discribtion'])){
    $Discribtion = sanitize($_POST['Discribtion']);
    if(strlen($Discribtion) < 30){
        echo "يجب ان يكون الوصف اكبر من 30 حرف <br>";
        $error = 1;
    }
}

if(!isset($error) && isset($_POST["Adding"]))
{
    $db = new Database();
    if($_GET['name']=="elec" || $_GET['name']=="watch")
    {
        $add = $db->Insert("INSERT INTO $tb (name,price_old,price_new,number_,Discound,	Discribtion,path)
        VALUES (?,?,?,?,?,?,?)",[$name,$Price,$new_price,$number_,$Discond,$Discribtion,$db_path]);
    }
    else

    $add = $db->Insert("INSERT INTO $tb (name,price_old,price_new,memory_,number_,Discound,	Discribtion,path)
    VALUES (?,?,?,?,?,?,?,?)",[$name,$Price,$new_price,$zise,$number_,$Discond,$Discribtion,$db_path]);
    if($add)
    {
        move_uploaded_file($_FILES["upload_image"]["tmp_name"],$db_path);
        echo 1;

    }
    else
    {
        echo "لديك خطاء ";
    }
}
////
if(!isset($error) && isset($_POST["Adding_compelete"]))
{
    $db = new Database();
    $add = $db->Insert("INSERT INTO $_GET[tbname_com] (name,price_old,price_new,memory_,number_,Discound,Discribtion,path)
    VALUES (?,?,?,?,?,?,?,?)",[$name,$Price,$new_price,$zise,$number_,$Discond,$Discribtion,$db_path]);
    if($add){
        move_uploaded_file($_FILES["upload_image"]["tmp_name"],$db_path);
        $id=intval($_GET["id"]);
        $del = $db->Delete("DELETE FROM complete_item WHERE Id=$id");
        unlink($_GET["path"]);

            echo 1;


        }
        else{
           echo "لديك خطاء ";
        }
}
if(!isset($error) && isset($_POST["buy"])) 
{
    $db = new Database();
    if(isset( $_SESSION['user']))
    {
        $old=intval($_GET['old'] )*intval($number_);
        $new=intval($_GET['new'])*intval($number_);
        $add = $db->Insert("INSERT INTO order_client_register (	email_user,id_order,count,detial,price_after,pric_before,checkk,tb_name,pay_type,sure)
        VALUES (?,?,?,?,?,?,?,?,?,?)",[$_SESSION['user'],$_GET['id'],$number_,$detial,$old,$new,0,$_GET['tb'],0,0]);
        if($add)
        {
            echo 1;
    
        }
        else
        {
            echo "لديك خطاء";
        }
    }
    else
    {
    $cehck_email = $db->GetRow("SELECT email FROM users WHERE email = ? LIMIT 1",[$_POST['email']]);
    if(!$cehck_email){
        $old=intval($_GET['old'] )*intval($number_);
        $new=intval($_GET['new'])*intval($number_);
        $add = $db->Insert("INSERT INTO orderr (username,email,phone,id_order,count,detial,price_after,pric_before,checkk,tb_name,pay_type,sure)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",[$name,$email,$phone,$_GET['id'],$number_,$detial,$old,$new,0,$_GET['tb'],0,0]);
        if($add)
        {
            $_SESSION["temp_user"]=$email;
            echo 1;
    
        }
        else
        {
            echo "لديك خطاء";
        }      
    
    }
    else
    {
        echo "هذا الايميل مسجل من قبل  <br>";
        $error = 1;
    }
}
}
// //////////////////////////addNews////////////////////////
if(!isset($error) && isset($_POST["Adding_news"]))
{
    $db = new Database();
    $add = $db->Insert("INSERT INTO news (photo,header_1,header_2,detail,price)
    VALUES (?,?,?,?,?)",[$db_path,$title,$name,$Discribtion,$Price]);
    if($add)
    {
        move_uploaded_file($_FILES["upload_image"]["tmp_name"],$db_path);
        echo 1;

    }
    else
    {
        echo "لديك خطاء ";
    }
}

}

?>