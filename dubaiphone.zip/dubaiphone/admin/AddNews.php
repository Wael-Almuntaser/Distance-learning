<?php
include "header_admin.php";
?>
  <!-- Header -->
  <header class="w3-container" style="padding-top:22px">
    <h5><b><i class="fa fa-dashboard"></i> My Dashboard</b></h5>
  </header>

  <script>
                function uploading()
    {
        let reader=new FileReader();
        reader.readAsDataURL(document.getElementById('upload_image').files[0]);
        reader.addEventListener('load',()=>{
            img=document.getElementById("image_chose").style.backgroundImage='url('+reader.result+')';
            document.getElementById("add_icon").style.display="none";
        });
    }
</script>
  <div class="container_R" id="container_A" style="direction: rtl;">
    <div id="error" class="alert alert-danger alert-dismissible fade show w-100" role="alert"></div>
    <div class="forms">
        <div class="form-content">
          <div class="login-form">
            <div class="title">ضافة خبر</div>
            <form action="#" id="sample_form" method="post" enctype="multipart/form-data">
            <div class="show_img" id="image_chose">
                <i class="icon_add" id="add_icon"></i>
                <input type="file" class="up_input" id="upload_image" name="upload_image" onchange="uploading(this)">
            </div>


          <div class="user-details">
                <div class="input-boxx">
                    <span class="details">العنوان </span>
                    <input type="text" placeholder="إدخل العنوان" id="title" name="title">
                  </div>
                  <div class="input-boxx">
                    <span class="details">الاسم </span>
                    <input type="text" placeholder="ادخل الاسم" id="name" name="name">
                  </div>
                  <div class="input-boxx">
                    <span class="details">السعر</span>
                    <input type="number" placeholder="ادخل السعر" id="Price" name="Price">
                  </div>
                  <input type="hidden" name="Adding_news" id="Adding_news">

                  <div class="input-boxx">
                    <span class="details">الوصف</span>
                    <textarea name="Discribtion" id="Discribtion" rows="10" cols="10"> 

                    </textarea>
                  </div>

              <div class="button">
                <input type="submit" id="submit" name="submit" value="إضافة">
              </div>
            
</div>
        </form>
        <div class="preloader-inner" id="preloader_1">
    <div class="preloader-icon">
        <span></span>
        <span></span>
    </div>
</div>
      </div>
    </div>
    </div>
  </div>


  <?php
include "footer_admin.php"
?>
<script>
  $(document).ready(function(){
    $("#preloader_1").hide();
    $("#error").hide();
    $('#sample_form').on('submit', function(event){
      event.preventDefault();
        $.ajax({
          url : "AddDB.php ? name=news",
          method:"POST",
          data: new FormData(this),
          contentType:false,
          cache:false,
          processData:false,
          success: function(response){
            if(response == 1){
              $("#preloader_1").show();
              $("#error").removeClass("alert-danger");
              $("#error").addClass("alert-primary");
              $("#error").show().html("جاري التنفيذ");
              setInterval(function () {
             window.location = "AddNews.php ? name=news";
              }, 2000);
           
               
            }
            else{
             $("#error").show().html(response);
            }
					}
        })  
    
      
        return false;
    })
  })

</script>