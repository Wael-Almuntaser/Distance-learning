<?php
include "header_admin.php";
require_once "../assets/dataBase/allTabel.php";
$db = new Database();
?>
<style>
    div#bbbbbb {
    padding: 39px 7px;
    background-color: white;
    box-shadow: 6px 9px 9px 26px 5px black;
    margin: 60px auto;
    box-shadow: 2px 3px 10px -1px;
    overflow-x: auto;
}
.KKKKM {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 30px;
}
span
{
    font-weight: bold;
}
</style>
<!doctype html>
<html lang="en">
	<body>
	<section class="ftco-section" style="direction: rtl;">
		<div class="container">
			<div class="row">
				<div class="col-md-12" id="bbbbbb">
					<div class="table-wrap">
						<table class="table table-responsive-xl">
                        
						  <thead>
						    <tr>
						    	<th>&nbsp;</th>
						      <th>الصورة</th>
                              <th>العدد</th>
                              <th>السعر قبل</th>
                              <th>السعر بعد</th>
                              <th>حذف</th>

						    </tr>
						  </thead>
						  <tbody id="order_item">
						    
						  </tbody>
     
						</table>
					</div>
				</div>

			</div>
		</div>
	</section>


	</body>
</html>

<script src="../assets/js/jquery.js"></script>
<script type="text/javascript">
    $(document).ready(function()
    {  $("#error").hide(); 
        var unsure="unsure";
        $.ajax({
            url:"aaa.php",
            data:
            {unsure:unsure},
            method:"post",
            success:function(data)
            {
                $("#order_item").html(data);
            }
        });
    });
    function Deleting_Unsure(e,p,tyyy)
    {
        var Deleting_order=e;
            var tp=p;
        var order_del_unsure="order_del_unsure";
        var tyyyyyy=tyyy;
        $.ajax({
            url:"aaa.php",
            data:
            {Deleting_order:Deleting_order,
                tp:tp,
                order_del_unsure:order_del_unsure,
                tyyyyyy:tyyyyyy,
            },

            method:"post",
            success:function(data)
            {
                $("#order_item").html(data);
            }
        });
    }


// <!-- /////////////////////////////////////////    Update Lock And Not Lock////////////////////// -->

</script>
</body>
</html>
<?php
include "footer_admin.php"; 
?>
