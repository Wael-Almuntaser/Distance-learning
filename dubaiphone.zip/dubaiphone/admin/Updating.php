<?php
include "header_admin.php";
?>
<style>
    img{
        width: 50px;
    }
</style>
<html>
<body>

</form>
<!-- KKKK TO get show more -->
<section class="trending-product section" style="margin-top: 12px;">
    <div class="container">
        <div class="sea">
            <h3>البحث</h3> <input type="text" id="live_search" autocomplete="off">
        </div>
        <div class="row" id="searchResult"></div>
    </div>
<div class="Con_num" id="KKKK"></div>
</section>



<!--  -->
<script src="../assets/js/jquery.js"></script>
<script type="text/javascript">
    $(document).ready(function()
    {  var main="main";
        var tb="<?php echo $_GET["name"] ?>";
        $.ajax({
            url:"aaa.php ? name="+tb+"",
            data:
            {main:main},
            method:"post",
            success:function(data)
            {
                $("#searchResult").html(data);
            }
        });
        
        $("#live_search").keyup(function()
        {
            var input=$(this).val();
            if(input !="")
            {
                $("#searchResult").css("display","flex");
                $.ajax({
                    url:"aaa.php ? name="+tb+"",
                    method:"post",
                    data:{input : input},
                    success:function(data)
                    {
                        $("#searchResult").html(data);
                    }
                });
            }
            else
            {
                $.ajax({
            url:"aaa.php ? name="+tb+"",
            data:
            {main:main},
            method:"post",
            success:function(data)
            {
                $("#searchResult").html(data);
            }
        });
            }
        });

    });
    function GoNext(params) {
        var next=params;
        var tb="<?php echo $_GET["name"] ?>";
        $.ajax({
            url:"aaa.php ? name="+tb+"",
            data:
            {next:next},
            method:"post",
            success:function(data)
            {
                $("#searchResult").html(data);
            }
        });
            }


</script>
</body>
</html>
<?php
include "footer_admin.php"; 
?>