<?php
session_start();
require_once "../assets/dataBase/allTabel.php";
if(!isset($_SESSION['Admin']))
{
    ?>
    <script>window.location = "Admin_login.php";</script>
  <script>alert("<?php echo $data["name"] ?>");</script>
<?php
}
else
{
  $db = new Database();
  $data = $db->GetRow("SELECT * from admin where email='$_SESSION[Admin]'");
}

?>
<!DOCTYPE html>
<html>
<head>
<title>Dashboard</title>
<style>
  .Menuuuu
  {
padding: 10px; 
margin-left: 15px;
cursor: pointer;
  }
</style>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.svg" />

    <!-- ========================= CSS here ========================= -->
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css" />
    <link rel="stylesheet" href="../assets/css/LineIcons.3.0.css" />
    <link rel="stylesheet" href="../assets/css/tiny-slider.css" />
    <link rel="stylesheet" href="../assets/css/glightbox.min.css" />
    <link rel="stylesheet" href="../assets/css/main.css" />
    <link rel="stylesheet" href="../assets/css/login_and_register.css" />
    <script src="../assets/js/jquery.js"></script>
<style>
html,body,h1,h2,h3,h4,h5 {font-family: "Raleway", sans-serif}
</style>
</head>
<body class="w3-light-grey">

<!-- Top container -->
<div class="w3-bar w3-top w3-black w3-large" style="z-index:4">
  <button class="w3-bar-item w3-button w3-hide-large w3-hover-none w3-hover-text-light-grey" onclick="w3_open();"><i class="fa fa-bars"></i>  Menu</button>
  <span class="w3-bar-item w3-right">Admin Dashboard</span>
</div>

<!-- Sidebar/menu -->
<nav class="w3-sidebar w3-collapse w3-white w3-animate-left" style="z-index:3;width:300px;" id="mySidebar"><br>
  <div class="w3-container w3-row" style="margin-top: 60px;">
    <div class="w3-col s8 w3-bar">
      <span>Welcome :  <strong><?php echo $data["name"]  ?></strong></span><br>
      <a href="logout_admin.php" class="w3-bar-item w3-button"><i class="fa fa-sign-out"></i></a>
      <a href="user_file.php" class="w3-bar-item w3-button"><i class="fa fa-cog"></i></a>
    </div>
  </div>
  <hr>
  <div class="w3-container">
    <h5>Dashboard</h5>
  </div>
  <div class="w3-bar-block">
  <a href="#" class="w3-bar-item w3-button w3-padding-16 w3-hide-large w3-dark-grey w3-hover-black" onclick="w3_close()" title="close menu"><i class="fa fa-remove fa-fw"></i> اغلاق</a>
    <a href="dashbord_admin.php" <?php basename($_SERVER['SCRIPT_NAME'])=="dashbord_admin.php" ? print "class='w3-bar-item w3-button w3-padding w3-blue'" : print "class='w3-bar-item w3-button w3-padding'" ?> ><i class="fa fa-users fa-fw"></i>  الرئيسية</a>
    <a href="client.php" <?php basename($_SERVER['SCRIPT_NAME'])=="client.php" ? print "class='w3-bar-item w3-button w3-padding w3-blue'" : print "class='w3-bar-item w3-button w3-padding'" ?>><i class="fa fa-users fa-fw"></i>  المستخدمين</a>
    <!-- iphone -->
    <div class="Menuuuu"  onclick="hideShow(this)"><i class="fa fa-list-alt"></i>  قسم الايفون
    <div style="display:none">
    <a href="addting.php?name=iphone"  <?php if(basename($_SERVER['SCRIPT_NAME']=="addting.php"  && $_GET['name']=='iphone')  ) echo "class='w3-bar-item w3-button w3-padding w3-blue'" ;else echo "class='w3-bar-item w3-button w3-padding'"; ?>><i class="fa fa-plus fa-fw"></i>  اضافة ايفون</a>
    <a href="Updating.php?name=iphone" <?php if(basename($_SERVER['SCRIPT_NAME']=="Updating.php" && $_GET['name']=='iphone')  ) echo "class='w3-bar-item w3-button w3-padding w3-blue'" ;else echo "class='w3-bar-item w3-button w3-padding'"; ?>><i class="fa fa-history fa-fw"></i> تعديل ايفون </a>
    <a href="Deleting.php?name=iphone" <?php if(basename($_SERVER['SCRIPT_NAME']=="Deleting.php" && $_GET['name']=='iphone')  ) echo "class='w3-bar-item w3-button w3-padding w3-blue'" ;else echo "class='w3-bar-item w3-button w3-padding'"; ?>><i class="fa fa-cog fa-fw"></i>حذف ايفون</a>
    </div>
    </div>
    <!--sumsang  -->
    <div class="Menuuuu"  onclick="hideShow(this)"><i class="fa fa-list-alt"></i>  قسم السامسونج
    <div style="display:none">
    <a href="addting.php?name=samsung" <?php basename($_SERVER['SCRIPT_NAME'])=="addting.php" ? print "class='w3-bar-item w3-button w3-padding w3-blue'" :print "class='w3-bar-item w3-button w3-padding'" ?>><i class="fa fa-plus fa-fw"></i> سامسونج اضافة</a>
    <a href="Updating.php?name=samsung" <?php basename($_SERVER['SCRIPT_NAME'])=="Updating.php" ? print "class='w3-bar-item w3-button w3-padding w3-blue'" :print "class='w3-bar-item w3-button w3-padding'" ?>><i class="fa fa-history fa-fw"></i> تعديل سامسونج</a>
    <a href="Deleting.php?name=samsung" <?php basename($_SERVER['SCRIPT_NAME'])=="Deleting.php" ? print "class='w3-bar-item w3-button w3-padding w3-blue'" :print "class='w3-bar-item w3-button w3-padding'" ?>><i class="fa fa-cog fa-fw"></i>حذف سامسونج</a>
    </div>
    </div>
    <!--  -->
    <!-- hawui -->
    <div class="Menuuuu"  onclick="hideShow(this)"><i class="fa fa-list-alt"></i>  قسم الهواوي
    <div style="display:none">
    <a href="addting.php?name=huawei" <?php basename($_SERVER['SCRIPT_NAME'])=="addting.php" ? print "class='w3-bar-item w3-button w3-padding w3-blue'" :print "class='w3-bar-item w3-button w3-padding'" ?>><i class="fa fa-plus fa-fw"></i> اضافةهواوي</a>
    <a href="Updating.php?name=huawei" <?php basename($_SERVER['SCRIPT_NAME'])=="Updating.php" ? print "class='w3-bar-item w3-button w3-padding w3-blue'" :print "class='w3-bar-item w3-button w3-padding'" ?>><i class="fa fa-history fa-fw"></i> تعديل هواوي</a>  
    <a href="Deleting.php?name=huawei" <?php basename($_SERVER['SCRIPT_NAME'])=="Deleting.php" ? print "class='w3-bar-item w3-button w3-padding w3-blue'" :print "class='w3-bar-item w3-button w3-padding'" ?>><i class="fa fa-cog fa-fw"></i>حذف هواوي</a>
  </div>
    </div>
    <!-- headphones -->
    <div class="Menuuuu"  onclick="hideShow(this)"><i class="fa fa-list-alt"></i>  قسم السماعات
    <div style="display:none">
    <a href="addting.php?name=hand" <?php basename($_SERVER['SCRIPT_NAME'])=="addting.php" ? print "class='w3-bar-item w3-button w3-padding w3-blue'" :print "class='w3-bar-item w3-button w3-padding'" ?>><i class="fa fa-plus fa-fw"></i> اضافة سماعات</a>
    <a href="Updating.php?name=hand" <?php basename($_SERVER['SCRIPT_NAME'])=="Updating.php" ? print "class='w3-bar-item w3-button w3-padding w3-blue'" :print "class='w3-bar-item w3-button w3-padding'" ?>><i class="fa fa-history fa-fw"></i> تعديل سماعات</a>
    <a href="Deleting.php?name=hand" <?php basename($_SERVER['SCRIPT_NAME'])=="Deleting.php" ? print "class='w3-bar-item w3-button w3-padding w3-blue'" :print "class='w3-bar-item w3-button w3-padding'" ?>><i class="fa fa-cog fa-fw"></i>حذف سماعات</a>
  </div>
</div>
    <!--  -->
    <!-- laptop -->
    <div class="Menuuuu"  onclick="hideShow(this)"><i class="fa fa-list-alt"></i>  قسم الاب نوب
    <div style="display:none">
    <a href="addting.php? name=laptop" <?php basename($_SERVER['SCRIPT_NAME'])=="addting.php" ? print "class='w3-bar-item w3-button w3-padding w3-blue'" :print "class='w3-bar-item w3-button w3-padding'" ?>><i class="fa fa-plus fa-fw"></i> اضافة لاب توب</a>
    <a href="Updating.php?name=laptop" <?php basename($_SERVER['SCRIPT_NAME'])=="Updating.php" ? print "class='w3-bar-item w3-button w3-padding w3-blue'" :print "class='w3-bar-item w3-button w3-padding'" ?>><i class="fa fa-history fa-fw"></i>تعديل لاب توب</a>
    <a href="Deleting.php?name=laptop" <?php basename($_SERVER['SCRIPT_NAME'])=="Deleting.php" ? print "class='w3-bar-item w3-button w3-padding w3-blue'" :print "class='w3-bar-item w3-button w3-padding'" ?>><i class="fa fa-cog fa-fw"></i>حذف لاب توب</a>
</div>
</div>
<!-- electronic -->
<div class="Menuuuu"  onclick="hideShow(this)"><i class="fa fa-list-alt"></i>  قسم الاجهزة الالكترونية
    <div style="display:none">
    <a href="addting.php?name=elec" <?php basename($_SERVER['SCRIPT_NAME'])=="addting.php" ? print "class='w3-bar-item w3-button w3-padding w3-blue'" :print "class='w3-bar-item w3-button w3-padding'" ?>><i class="fa fa-plus fa-fw"></i> اضافة  حهاز الكتروني</a>
    <a href="Updating.php?name=elec" <?php basename($_SERVER['SCRIPT_NAME'])=="Updating.php" ? print "class='w3-bar-item w3-button w3-padding w3-blue'" :print "class='w3-bar-item w3-button w3-padding'" ?>><i class="fa fa-history fa-fw"></i>تعديل حهاز الكتروني</a>
    <a href="Deleting.php?name=elec" <?php basename($_SERVER['SCRIPT_NAME'])=="Deleting.php" ? print "class='w3-bar-item w3-button w3-padding w3-blue'" :print "class='w3-bar-item w3-button w3-padding'" ?>><i class="fa fa-cog fa-fw"></i>حذف جهاز الكتروني</a>
</div>
</div>
<!--  -->
<!-- watch -->
<div class="Menuuuu"  onclick="hideShow(this)"><i class="fa fa-list-alt"></i>  قسم الساعات
    <div style="display:none">
    <a href="addting.php?name=watch" <?php basename($_SERVER['SCRIPT_NAME'])=="addting.php" ? print "class='w3-bar-item w3-button w3-padding w3-blue'" :print "class='w3-bar-item w3-button w3-padding'" ?>><i class="fa fa-plus fa-fw"></i> اضافة ساعه</a>
    <a href="Updating.php?name=watch" <?php basename($_SERVER['SCRIPT_NAME'])=="Updating.php" ? print "class='w3-bar-item w3-button w3-padding w3-blue'" :print "class='w3-bar-item w3-button w3-padding'" ?>><i class="fa fa-history fa-fw"></i>تعديل  ساعه</a>
    <a href="Deleting.php?name=watch" <?php basename($_SERVER['SCRIPT_NAME'])=="Deleting.php" ? print "class='w3-bar-item w3-button w3-padding w3-blue'" :print "class='w3-bar-item w3-button w3-padding'" ?>><i class="fa fa-cog fa-fw"></i>حذف ساعه</a>
</div>
</div>
<!--  -->
    <!--  -->
    <!-- news -->
    <div class="Menuuuu"  onclick="hideShow(this)"><i class="fa fa-list-alt"></i>  قسم الاخبار
    <div style="display:none">
    <a href="AddNews.php" <?php basename($_SERVER['SCRIPT_NAME'])=="AddNews.php" ? print "class='w3-bar-item w3-button w3-padding w3-blue'" :print "class='w3-bar-item w3-button w3-padding'" ?>><i class="fa fa-shopping-cart fa-fw"></i>  اضافة اخبار</a>
    <a href="UpdateNews.php?name=iphone" <?php basename($_SERVER['SCRIPT_NAME'])=="UpdateNews.php" ? print "class='w3-bar-item w3-button w3-padding w3-blue'" :print "class='w3-bar-item w3-button w3-padding'" ?>><i class="fa fa-history fa-fw"></i> تعديل اخبار </a>
    <a href="DeleteNews.php?name=iphone" <?php basename($_SERVER['SCRIPT_NAME'])=="DeleteNews.php" ? print "class='w3-bar-item w3-button w3-padding w3-blue'" :print "class='w3-bar-item w3-button w3-padding'" ?>><i class="fa fa-cog fa-fw"></i>حذف اخبار</a>
</div>
</div>
    <!--  -->
    <!-- order -->
    <div class="Menuuuu"  onclick="hideShow(this)"><i class="fa fa-list-alt"></i>  قسم الطلبات
    <div style="display:none">
    <a href="order.php" <?php basename($_SERVER['SCRIPT_NAME'])=="order.php" ? print "class='w3-bar-item w3-button w3-padding w3-blue'" : print "class='w3-bar-item w3-button w3-padding'" ?>><i class="fa fa-shopping-cart fa-fw"></i>  الطلبات</a>
    <a href="accept_order.php" <?php basename($_SERVER['SCRIPT_NAME'])=="accept_order.php" ? print "class='w3-bar-item w3-button w3-padding w3-blue'" :print "class='w3-bar-item w3-button w3-padding'" ?>><i class="fa fa-shopping-cart fa-fw"></i>  الطلبات المقبوله</a>
    <a href="unsure.php" <?php basename($_SERVER['SCRIPT_NAME'])=="unsure.php" ? print "class='w3-bar-item w3-button w3-padding w3-blue'" :print "class='w3-bar-item w3-button w3-padding'" ?>><i class="fa fa-shopping-cart fa-fw"></i>  الطلبات الغير موكدة</a>
    <!-- <a href="complete_item.php" <?php basename($_SERVER['SCRIPT_NAME'])=="complete_item.php" ? print "class='w3-bar-item w3-button w3-padding w3-blue'" :print "class='w3-bar-item w3-button w3-padding'" ?>><i class="fa fa-users fa-fw"></i>  Complete item</a>   -->
  </div>
    </div>
    <a href="complete_item.php" <?php basename($_SERVER['SCRIPT_NAME'])=="complete_item.php" ? print "class='w3-bar-item w3-button w3-padding w3-blue'" :print "class='w3-bar-item w3-button w3-padding'" ?>><i class="fa fa-users fa-fw"></i>  الاصناف المكمله</a>
    <a href="contact.php" <?php basename($_SERVER['SCRIPT_NAME'])=="contact.php" ? print "class='w3-bar-item w3-button w3-padding w3-blue'" :print "class='w3-bar-item w3-button w3-padding'" ?>><i class="	fa fa-gears"></i>  معلومات التواصل </a>
    <a href="language.php" <?php basename($_SERVER['SCRIPT_NAME'])=="language.php" ? print "class='w3-bar-item w3-button w3-padding w3-blue'" :print "class='w3-bar-item w3-button w3-padding'" ?>><i class="	fa fa-language"></i>  عملة الموقع</a>
    <!--  -->
    <!--  -->
    <br><br>
  </div>
</nav>


<!-- Overlay effect when opening sidebar on small screens -->
<div class="w3-overlay w3-hide-large w3-animate-opacity" onclick="w3_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>

<!-- !PAGE CONTENT! -->
<div class="w3-main" style="margin-left:300px;margin-top:43px;">
