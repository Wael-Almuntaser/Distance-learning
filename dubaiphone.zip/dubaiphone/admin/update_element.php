<?php
include "header_admin.php";
require_once "../assets/dataBase/allTabel.php";
$db = new Database();
?>



  <!-- Header -->
  <header class="w3-container" style="padding-top:22px">
    <h5><b><i class="fa fa-dashboard"></i> My Dashboard</b></h5>
  </header>

  <script>
                function uploading()
    {
        let reader=new FileReader();
        reader.readAsDataURL(document.getElementById('upload_image').files[0]);
        reader.addEventListener('load',()=>{
            img=document.getElementById("image_chose").style.backgroundImage='url('+reader.result+')';
            document.getElementById("add_icon").style.display="none";
        });
    }
</script>
<?php
    $selet = $GLOBALS['db']->GetRow("SELECT * from $_GET[name] where Id=$_GET[id]"); 
    if(count($selet))
    {
        ?>
         <div class="container_R" id="container_A" style="direction: rtl;">
    <div id="error" class="alert alert-danger alert-dismissible fade show w-100" role="alert"></div>
    <div class="forms">
        <div class="form-content">
          <div class="login-form">
            <div class="title">تعديل <?php echo $_GET["name"]  ?></div>
            <form action="#" id="sample_form" method="post" enctype="multipart/form-data">
            <div class="show_img" id="image_chose">
                <i class="icon_add" id="add_icon" style="background-image: url(<?php echo $selet['path'] ?>);"></i>
                <input type="file" class="up_input" id="upload_image" name="upload_image" onchange="uploading(this)" value="<?php echo $selet['path'] ?>">
            </div>


          <div class="user-details">
                <div class="input-boxx">
                    <span class="details">الاسم</span>
                    <input type="text" value="<?php echo $selet["name"]  ?>" id="name" name="name" >
                  </div>
                  <div class="input-boxx">
                    <span class="details">السعر</span>
                    <input type="number" value="<?php echo $selet["price_old"]  ?>" id="Price" name="Price">
                  </div>
                  <!--  -->
                  <?php
                    if(!($_GET['name']=="electronic" || $_GET['name']=="watch"))
                    {
                      ?>
                      <div class="col-lg-4 col-md-4 col-12">
                    <div class="form-group">
                        <span class="details">الذاكرة</span>
                        <select class="form-control" id="zise" name="zise" value="<?php echo $selet["memory_"]  ?>">
                            <option>1 تيرا </option>
                            <option>512 جيجا</option>
                            <option>256 جيجا</option>
                            <option>128 جيجا</option>
                        </select>
                    </div>
                </div>
                      <?php
                    }
                  ?>

                <!--  -->
                <div class="input-boxx">
                  <input type="hidden" name="update_item" id="update_item">
                    <span class="details">الكمية المتاحة</span>
                    <input type="number" value="<?php echo $selet["number_"]  ?>" id="number_" name="number_">
                  </div>
                <div class="input-boxx">
                    <span class="details">التخفيض</span>
                    <input type="number" value="<?php echo $selet["Discound"]  ?>" id="Discond" name="Discond">
                  </div>
                  <div class="input-boxx">
                    <span class="details">الوصف</span>
                    <textarea name="Discribtion" id="Discribtion" rows="10" cols="10">
                    <?php echo $selet["Discribtion"]  ?>
                    </textarea>
                  </div>

              <div class="button">
                <input type="submit" id="submit" name="submit" value="تعديل">
              </div>
            
</div>
        </form>
        <div class="preloader-inner" id="preloader_1">
    <div class="preloader-icon">
        <span></span>
        <span></span>
    </div>
</div>
      </div>
    </div>
    </div>
  </div>


        <?php

    }
?>

 


  <?php
include "footer_admin.php"
?>
<script>
  $(document).ready(function(){
    $("#preloader_1").hide();
    $("#error").hide();
    $('#sample_form').on('submit', function(event){
      event.preventDefault();
        $.ajax({
          url : "updateDB.php ?  id=<?php echo $_GET["id"] ?> & name=<?php echo $_GET['name'] ?> ",
          method:"POST",
          data: new FormData(this),
          contentType:false,
          cache:false,
          processData:false,
          success: function(response){
            if(response == 1){
              $("#preloader_1").show();
              $("#error").removeClass("alert-danger");
              $("#error").addClass("alert-primary");
              $("#error").show().html("جاري النعديل");
              setInterval(function () {
             window.location = "update_element.php?name=<?php echo $_GET['name'] ?>&id=<?php echo $_GET["id"] ?>";
              }, 2000);
           
               
            }
            else{
             $("#error").show().html(response);
            }
					}
        })  
    
      
        return false;
    })
  })

</script>