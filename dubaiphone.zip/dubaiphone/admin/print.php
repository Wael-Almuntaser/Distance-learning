<?php
require_once "../vendor/autoload.php";
require_once "../assets/dataBase/allTabel.php";
require_once '../dompdf/autoload.inc.php';
use Dompdf\Dompdf;
use Dompdf\Options;
$db = new Database();
extract($_POST);
$html='';

$name ="Sultan";
$quantity = "saeed";

$options = new Options;
$options->setChroot(__DIR__);
$options->setIsRemoteEnabled(true);

$dompdf = new Dompdf($options);
$dompdf->setPaper("A4", "landscape");

$html = file_get_contents("tem.html");
$seletttt = $db->GetRow("SELECT username,email,phone from orderr where email='algoami2020@gmail.com' limit 1");
$photo= $db->GetRow("SELECT icon from icon_num limit 1");
$html = str_replace(["{{ username }}", "{{ email }}","{{phone}}","{{photo}}"], [$seletttt['username'], $seletttt['email'],$seletttt['phone'],$photo["icon"]], $html);

$dompdf->loadHtml($html);
$dompdf->render();

$dompdf->addInfo("Title", "An Example PDF");

$dompdf->stream("invoice.pdf", ["Attachment" => 0]);

// $html .='
// <html lang=en>
// <body style="font-family:Arial">
// <section class="ftco-section" style="direction: rtl;">
// <div class="container">
// <div class="row">
// <div class="col-md-12" style="padding: 39px 7px; background-color: white; box-shadow: 6px 9px 9px 26px 5px black;margin: 60px auto;box-shadow: 2px 3px 10px -1px;">
// <div class="table-wrap">
// ';

// $count="";
// if(isset($_GET['register']) && $_GET['register']=="1" )
// {
//     $seletttt = $db->GetRow("SELECT name,Username,email,phone from users where email='$_GET[email]'");
//     $photo= $db->GetRow("SELECT icon from icon_num limit 1");
//     $html .="
//     <table>
//     <tr><td>الاسم</td><td>$seletttt[name]</td><td>الايميل</td><td>$seletttt[email]</td></tr>
//     <tr><td>اسم المستخدم</td><td>$seletttt[Username]</td><td>الرقم</td><td>$seletttt[phone] </td></tr>
//   </table>
//     ";
// }
// if(isset($_GET['register']) && $_GET['register']=="0" )
// {
// $seletttt = $db->GetRow("SELECT username,email,phone from orderr where email=$_GET[email] limit 1");
// $photo= $db->GetRow("SELECT icon from icon_num limit 1");
// $html .="
// <table style='width:130%; color:red ' >
// <tr><td>الاسم</td><td>Mohmmed</td><td>الايميل</td><td>Mohmmed@gmail.com</td></tr>
// <tr><td colspan='2' style='margin-right:20%'><center><img src='1.JPG'></center></td></tr>
// <tr><td>اسم المستخدم</td><td>Mohmmed</td><td>الرقم</td><td>888888888888 </td></tr>
// </table>
// ";

// }
// $html .='
// <table class="table table-responsive-xl">
                        
// <thead>
//   <tr>
//       <th>&nbsp;</th>
//     <th>الصورة</th>
//     <th>الرقم</th>
//     <th>السعر قبل</th>
//     <th>السعر بعد</th>
//     <th>حذف</th>

//   </tr>
// </thead>
// ';

// $html .='
// <tbody id="order_item">
						    
// </tbody>
// ';







// $html .='
// </table>
// </div>

// </div>

// </div>
// </div>
// </section>


// </body>
// </html>
// ';
$options = new Options;
$options->setChroot(__DIR__);
$dompdf = new Dompdf($options);
$html .="<h2>انا سلطان</h2>";
$pdfff = new Dompdf();
$pdfff->loadHtml($html);
$pdfff->setPaper('A4', 'landscape');
$pdfff->render();
$pdfff->stream("data.pdf");

?>

