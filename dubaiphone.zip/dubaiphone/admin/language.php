<?php
include "header_admin.php";
?>
  <!-- Header -->
  <header class="w3-container" style="padding-top:22px">
    <h5><b><i class="fa fa-dashboard"></i> My Dashboard</b></h5>
  </header>

  <div class="container_R" id="container_A" style="direction: rtl;">
    <div id="error" class="alert alert-danger alert-dismissible fade show w-100" role="alert"></div>
    <div class="forms">
        <div class="form-content">
          <div class="login-form">
            <div class="title">تعديل العملة</div>
            <form action="#" id="sample_form" method="post" enctype="multipart/form-data">
          <div class="user-details">
                  <input type="hidden" name="language" id="language">
                  <div class="col-lg-4 col-md-4 col-12">
                    <div class="form-group">
                        <span class="details">عملة الموقع</span>
                        <select class="form-control" id="zise" name="zise">
                            <?php
                            $db = new Database();
                            $langage = $db->GetRow("SELECT 	* from language ");
                            ?>
                            <option value="USD" selected><?php echo $langage['language']; ?></option>
                            <option value="USD" >الدولار الأمريكي</option>
                            <option value="EUR">اليورو </option>
                            <option value="GBP">الجنيه الإسترليني</option>
                            <option value="EGP">جنيه مصري</option>
                            <option value="SAR">ريال سعودي</option>
                            <option value="YER">ريال يمني</option>
                            <option value="QAR">ريال قطري</option>
                            <option value="AED">درهم إماراتي</option>
                            <option value="OMR">ريال عماني</option>
                            <option value="BHD">دينار بحريني</option>
                            <option value="KWD">دينار كويتي</option>
                        </select>
                    </div>
                </div>



              <div class="button">
                <input type="submit" id="submit" name="submit" value="اضافة">
              </div>
            
</div>
        </form>
        <div class="preloader-inner" id="preloader_1">
    <div class="preloader-icon">
        <span></span>
        <span></span>
    </div>
</div>
      </div>
    </div>
    </div>
  </div>


  <?php
include "footer_admin.php"
?>
<script>
  $(document).ready(function(){
    $("#preloader_1").hide();
    $("#error").hide();
    $('#sample_form').on('submit', function(event){
      event.preventDefault();
        $.ajax({
          url : "aaa.php",
          method:"POST",
          data: new FormData(this),
          contentType:false,
          cache:false,
          processData:false,
          success: function(response){
            if(response == 1){
              $("#preloader_1").show();
              $("#error").removeClass("alert-danger");
              $("#error").addClass("alert-primary");
              $("#error").show().html("جاري التعديل....");
              setInterval(function () {
             window.location = "language.php";
              }, 2000);
           
               
            }
            else{
             $("#error").show().html(response);
            }
					}
        })  
    
      
        return false;
    })
  })

</script>