<?php
require_once "../assets/dataBase/allTabel.php";
$newpath="";
$tb="";
$db = new Database();
function sanitize($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
    return $data;
}
if(isset($_GET['name']))
{
    if($_GET['name']=="iphone_e"){ $newpath="iphone_img"; $tb="iphone_e" ;}
    if($_GET['name']=="samsung_e"){ $newpath="samsung_img"; $tb="samsung_e";}
    if($_GET['name']=="huawei_e") {$newpath="huawei_img"; $tb="huawei_e";}
    if($_GET['name']=="hande_e"){ $newpath="hande_img"; $tb="hande_e";}
    if($_GET['name']=="laptop_e"){ $newpath="laptop_img"; $tb="laptop_e";}
    if($_GET['name']=="electronic"){ $newpath="elec_img"; $tb="electronic";}
    if($_GET['name']=="watch"){ $newpath="watch_img"; $tb="watch";}
}
else{
    echo "اختر المسار اولا";
    $error=1;
}
$selet = $GLOBALS['db']->GetRow("SELECT * from $_GET[name] where Id=$_GET[id]"); 
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

if(isset($_FILES['upload_image']["name"]))
{

if($_FILES['upload_image']["name"]!="")
{  
    $t1=true;

        //    it will be in end  
        $path_Only=basename($_FILES['upload_image']["name"]);
        $path_exp=explode('.',$path_Only);
        $ex=$path_exp[count($path_exp)-1];
        $new_path=round(microtime(true)).'.'.end($path_exp);
        $db_path="";
        if($ex=="jpg" || $ex=="png" || $ex=="jpeg")
        {
            if(is_uploaded_file($_FILES["upload_image"]["tmp_name"]))
            {
    
                 $db_path="../assets/$newpath/".$new_path;
            }
            else
            {
                echo "لايمكن تحميل الصورة<br>";
                $error=1;
            }
        }
        else
        {
            echo "فقط JPG, PNG , JPEG<br>";
            $error=1; 
        }

}
else
{$t1=false;}


}
// 

// 

if(isset($_POST['name'])){
    $name = sanitize($_POST['name']);
    if($_GET["name"]=="news")
    {
        $name__=$selet["header_1"];
    }
    else
    {
        $name__=$selet["name"]  ;
    }
    if($name!=$name__)
    {
        $t2=true;
        if(strlen($name) < 6){
            echo "الاسم يجب ان يكون اكبر من 6 احرف <br>";
            $error = 1;
        }
    }
    else
    {
        $t2=false;
    }

}
if(isset($_POST['title'])){
    $title = sanitize($_POST['title']);
    if($title!=$selet["header_2"])
    {
        $t2=true;
        if(strlen($name) < 6){
            echo "العنوان يجب ان يكون اكبر من 6 احرف <br>";
            $error = 1;
        }
    }
    else
    {
        $t2=false;
    }

}
if(isset($_POST['Price'])){
    $Price = sanitize($_POST['Price']);
    $price__=0;
    if($_GET["name"]=="news")
    {
        $price__=$selet["price"];
    }
    else
    {
        $name__=$selet["price_old"]  ;
    }
    if(intval( $Price ) != intval( $price__))
    {
        $t3=true;
        $Price=intval($Price);
        if(strlen($Price) < 1){
            echo "السعر يجب ان يكون اكبر من 6 احرف  <br>";
            $error = 1;
        }
    }
    else
    {
        $t3=false;
    }

}
if(isset($_POST['zise'])){
    $zise = sanitize($_POST['zise']);
    if($zise != $selet["memory_"] )
    {
        $t4=true;
        if(strlen($zise) < 1){
            echo "اختر حجم الذاكرة <br>";
            $error = 1;
        }
    }
    else
    {
        $t4=false;
    }

}
if(isset($_POST['number_'])){
    $number_ = sanitize($_POST['number_']);
    if($number_ >0){
    if($number_ != $selet["number_"])
    {
        $t5=true;
        if(strlen($number_) < 1){
            echo "لايمكن ان تكون الكمية المتاحة اقل من الواحد<br>";
            $error = 1;
        }
    }
    else
    {
        $t5=false;
    }
}
else
{
    echo "الكمية المتاحة مطلوبة ";
    $error=1;
}

}
if(isset($_POST['Discond'])){

    $Discond = sanitize($_POST['Discond']);
       if($Discond != $selet["Discound"])
       {
        $t6=true;
        $Discond=intval($Discond);
        if($Discond==0) $new_price=0;
        else
        {
            $new_price=$Price - $Price*($Discond/100);
        }
        if(strlen($Discond) < 1){
            echo "التخفيص مهم اذا لم يوحد اضغط 0  <br>";
            $error = 1;
        }
    }
    else
    {
        $new_price=$selet["price_new"];
        $t6=false;
    }

}
if(isset($_POST['Discribtion'])){
    $Discribtion = sanitize($_POST['Discribtion']);
    if($_GET["name"]=="news")
    {
        $disc__=$selet["detail"];
    }
    else
    {
        $disc__=$selet["Discribtion"]  ;
    }
    if($Discribtion != $disc__)
    {
        $t7=true;
            if(strlen($Discribtion) < 30){
        echo "يجب ان يكون الوصف اكبر من 30 حرف  <br>";
        $error = 1;
    }
    }
    else
    {
        $t7=false;
    }

}


if(!isset($error) && isset($_POST["update_item"]) )
{
    
    if(!($t1 || $t2 || $t3 || $t4 || $t5 || $t7 || $t6))
    {
        echo "لايوجد تغير في المحتوى";
    }
    else
    {
        if($t1)
        {
            if($_GET['name']=="electronic" || $_GET['name']=="watch")
            {
                $update=$db->Update("UPDATE $_GET[name] SET name = '$name',price_old=$Price,price_new=$new_price,number_=$number_,Discound=$Discond,Discribtion='$Discribtion',path='$db_path'   WHERE Id='$_GET[id]' ");
            }
            else
            {
            $update=$db->Update("UPDATE $_GET[name] SET name = '$name',price_old=$Price,price_new=$new_price,memory_='$zise',number_=$number_,Discound=$Discond,Discribtion='$Discribtion',path='$db_path'   WHERE Id='$_GET[id]' ");
            }
            if($update)
        {
            unlink($selet["path"]);
            move_uploaded_file($_FILES["upload_image"]["tmp_name"],$db_path);
            echo 1;
        }
        else
        {
            echo "لديك خطاء ";
        }
        }
        else
        {
            if($_GET['name']=="electronic" || $_GET['name']=="watch")
            {
                $update=$db->Update("UPDATE $_GET[name] SET name = '$name',price_old=$Price,price_new=$new_price,number_=$number_,Discound=$Discond,Discribtion='$Discribtion'   WHERE Id='$_GET[id]' ");
            }
            else
            {
            $update=$db->Update("UPDATE $_GET[name] SET name = '$name',price_old=$Price,price_new=$new_price,memory_='$zise',number_=$number_,Discound=$Discond,Discribtion='$Discribtion'   WHERE Id='$_GET[id]' ");
            }
        if($update)
        {
            echo 1;
        }
        else
        {
            echo "لديك خطاء ";
        }
    }
    }
    
}
///////////////////////update_item_news
if(!isset($error) && isset($_POST["update_item_news"]) )
{
    
    if(!($t1 || $t2 || $t3 || $t4 || $t5 || $t7 || $t6))
    {
        echo "لايوجد تغير بالمحتوى";
    }
    else
    {
        if($t1)
        {
            $update=$db->Update("UPDATE $_GET[name] SET header_1 = '$name',header_2	='$title',price=$Price,detail='$Discribtion', photo='$db_path'   WHERE Id='$_GET[id]' ");
        if($update)
        {
            unlink($selet["photo"]);
            move_uploaded_file($_FILES["upload_image"]["tmp_name"],$db_path);
            echo 1;
        }
        else
        {
            echo "لديك خطاء ";
        }
        }
        else
        {
            $update=$db->Update("UPDATE $_GET[name] SET header_1 = '$name',header_2	='$title',price=$Price,detail='$Discribtion'   WHERE Id='$_GET[id]' ");
        if($update)
        {
            echo 1;
        }
        else
        {
            echo "لديك خطاء ";
        }
    }
    }
    
}




}
?>