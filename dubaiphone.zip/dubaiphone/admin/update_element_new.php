<?php
include "header_admin.php";
require_once "../assets/dataBase/allTabel.php";
$db = new Database();
?>



  <!-- Header -->
  <header class="w3-container" style="padding-top:22px">
    <h5><b><i class="fa fa-dashboard"></i> My Dashboard</b></h5>
  </header>

  <script>
                function uploading()
    {
        let reader=new FileReader();
        reader.readAsDataURL(document.getElementById('upload_image').files[0]);
        reader.addEventListener('load',()=>{
            img=document.getElementById("image_chose").style.backgroundImage='url('+reader.result+')';
            document.getElementById("add_icon").style.display="none";
        });
    }
</script>
<?php
    $selet = $GLOBALS['db']->GetRow("SELECT * from $_GET[name] where Id=$_GET[id]"); 
    if(count($selet))
    {
        ?>
         <div class="container_R" id="container_A">
    <div id="error" class="alert alert-danger alert-dismissible fade show w-100" role="alert"></div>
    <div class="forms">
        <div class="form-content">
          <div class="login-form">
            <div class="title">تعديل الخبر</div>
            <form action="#" id="sample_form" method="post" enctype="multipart/form-data">
            <div class="show_img" id="image_chose">
                <i class="icon_add" id="add_icon" style="background-image: url(<?php echo $selet['photo'] ?>);"></i>
                <input type="file" class="up_input" id="upload_image" name="upload_image" onchange="uploading(this)" value="<?php echo $selet['photo'] ?>">
            </div>


          <div class="user-details">
                <div class="input-boxx">
                    <span class="details">العنوان</span>
                    <input type="text" value="<?php echo $selet["header_1"]  ?>" id="title" name="title" >
                  </div>
                  <div class="input-boxx">
                    <span class="details">الاسم </span>
                    <input type="text" placeholder="Enter The Name" value="<?php echo $selet["header_2"]  ?>" id="name" name="name">
                  </div>
                  <div class="input-boxx">
                    <span class="details">السعر</span>
                    <input type="number" value="<?php echo $selet["price"]  ?>" id="Price" name="Price">
                  </div>


                  <input type="hidden" name="update_item_news" id="update_item_news">
                  <div class="input-boxx">
                    <span class="details">الوصف</span>
                    <textarea name="Discribtion" id="Discribtion" rows="10" cols="10">
                    <?php echo $selet["detail"]  ?>
                    </textarea>
                  </div>

              <div class="button">
                <input type="submit" id="submit" name="submit" value="تعديل">
              </div>
            
</div>
        </form>
        <div class="preloader-inner" id="preloader_1">
    <div class="preloader-icon">
        <span></span>
        <span></span>
    </div>
</div>
      </div>
    </div>
    </div>
  </div>


        <?php

    }
?>

 


  <?php
include "footer_admin.php"
?>
<script>
  $(document).ready(function(){
    $("#preloader_1").hide();
    $("#error").hide();
    $('#sample_form').on('submit', function(event){
      event.preventDefault();
        $.ajax({
          url : "updateDB.php ?  id=<?php echo $_GET["id"] ?> & name=<?php echo $_GET['name'] ?> ",
          method:"POST",
          data: new FormData(this),
          contentType:false,
          cache:false,
          processData:false,
          success: function(response){
            if(response == 1){
              $("#preloader_1").show();
              $("#error").removeClass("alert-danger");
              $("#error").addClass("alert-primary");
              $("#error").show().html("Account created success");
              setInterval(function () {
             window.location = "update_element_new.php? name=<?php echo $_GET['name'] ?> & id=<?php echo $_GET["id"] ?>";
              }, 2000);
           
               
            }
            else{
             $("#error").show().html(response);
            }
					}
        })  
    
      
        return false;
    })
  })

</script>