<?php
include "header_admin.php";
require_once "../assets/dataBase/allTabel.php";
$db = new Database();
?>



  <!-- Header -->
  <header class="w3-container" style="padding-top:22px">
    <h5><b><i class="fa fa-dashboard"></i> My Dashboard</b></h5>
  </header>

  <script>
                function uploading()
    {
        let reader=new FileReader();
        reader.readAsDataURL(document.getElementById('upload_image').files[0]);
        reader.addEventListener('load',()=>{
            img=document.getElementById("image_chose").style.backgroundImage='url('+reader.result+')';
            document.getElementById("add_icon").style.display="none";
        });
    }
</script>
<?php
    $selet = $GLOBALS['db']->GetRow("SELECT * from complete_item where Id=$_GET[id]"); 
    if(count($selet))
    {
        ?>
         <div class="container_R" id="container_A">
    <div id="error" class="alert alert-danger alert-dismissible fade show w-100" role="alert"></div>
    <div class="forms">
        <div class="form-content">
          <div class="login-form">
            <div class="title"> Adding to tabel : <?php echo $selet['tb_name']?></div>
            <form action="#" id="sample_form" method="post" enctype="multipart/form-data">
            <div class="show_img" id="image_chose">
                <i class="icon_add" id="add_icon" style="background-image: url(<?php echo $selet['path'] ?>);"></i>
                <input type="file" class="up_input" id="upload_image" name="upload_image" onchange="uploading(this)" value="<?php echo $selet['path'] ?>">
            </div>


          <div class="user-details">
                <div class="input-boxx">
                    <span class="details">Name</span>
                    <input type="text" value="<?php echo $selet["name"]  ?>" id="name" name="name" >
                  </div>
                  <div class="input-boxx">
                    <span class="details">Price</span>
                    <input type="number" value="<?php echo $selet["price_old"]  ?>" id="Price" name="Price">
                  </div>
                  <div class="col-lg-4 col-md-4 col-12">
                    <div class="form-group">
                        <span class="details">Memory</span>
                        <select class="form-control" id="zise" name="zise" value="<?php echo $selet["memory_"]  ?>">
                            <option>1 Tura </option>
                            <option>512 Giga</option>
                            <option>256 Giga</option>
                            <option>128 Giga</option>
                        </select>
                    </div>
                </div>
                <input type="hidden" name="Adding_compelete" id="Adding_compelete">
                <div class="input-boxx">
                    <span class="details">Number</span>
                    <input type="number" value="<?php echo $selet["number_"]  ?>" id="number_" name="number_">
                  </div>
                <div class="input-boxx">
                    <span class="details">Discound</span>
                    <input type="number" value="<?php echo $selet["Discound"]  ?>" id="Discond" name="Discond">
                  </div>
                  <div class="input-boxx">
                    <span class="details">Discribtion</span>
                    <textarea name="Discribtion" id="Discribtion" rows="10" cols="10">
                    <?php echo $selet["Discribtion"]  ?>
                    </textarea>
                  </div>

              <div class="button">
                <input type="submit" id="submit" name="submit" value="Add">
              </div>
            
</div>
        </form>
        <div class="preloader-inner" id="preloader_1">
    <div class="preloader-icon">
        <span></span>
        <span></span>
    </div>
</div>
      </div>
    </div>
    </div>
  </div>


        <?php

    }
?>

 


  <?php
include "footer_admin.php"
?>
<script>
  $(document).ready(function(){
    $("#preloader_1").hide();
    $("#error").hide();
    var loc="";
    var folder="<?php echo $_GET['tbnamp']?>";
    if(folder=="iphone_e "){ loc="iphone_img";}
    if(folder=="samsung_e ") loc="samsung_img";
    if(folder=="huawei_e ") loc="huawei_img";
    if(folder=="hande_e ") loc="hande_img";
    if(folder=="laptop_e ") loc="laptop_img";
    $('#sample_form').on('submit', function(event){
      event.preventDefault();
        $.ajax({
          url : "AddDB.php?tbname_com=<?php echo $_GET['tbnamp']?>&folder="+loc+"&id=<?php echo $_GET['id']?>&path=<?php echo $_GET['path']?>",
          method:"POST",
          data: new FormData(this),
          contentType:false,
          cache:false,
          processData:false,
          success: function(response){
            if(response == 1){
              $("#preloader_1").show();
              $("#error").removeClass("alert-danger");
              $("#error").addClass("alert-primary");
              $("#error").show().html("جاري التنفيذ");
              setInterval(function () {
             window.location = "complete_item.php";
              }, 2000);
           
               
            }
            else{
             $("#error").show().html(response);
            }
					}
        })  
    
      
        return false;
    })
  })

</script>