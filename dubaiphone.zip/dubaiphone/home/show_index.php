<?php
session_start(); 
require_once "../assets/dataBase/allTabel.php";
$db = new Database();
$langage=$db->GetRow("SELECT * from language where Id=1 ");
function GetRowss($tb,$url,$head,$title)
{
    $db = new Database();
    if($tb=="electronic" || $tb=="watch")
    {
        $selet = $db->GetRows("SELECT Id,path,name,number_,price_old,price_new,Discound,Discribtion from $tb order by number_ desc limit 0,8 ");
    }
    else
    {
    $selet = $db->GetRows("SELECT Id,path,name,number_,price_old,price_new,memory_,Discound,Discribtion from $tb order by number_ desc limit 0,8 ");
    }
    if(count($selet)){
    ?>
    <center>
    <h4 style="background-color: #e1e8ff4d; padding: 10px;    box-shadow: 1px 3px 3px -1px;" ><?php echo $head ?></h4> 
    </center>
    <?php
     foreach($selet as $val) { 
        if(intval($val["number_"] >0)){
        ?>
        <div class="col-lg-3 col-md-6 col-12" id="respon">
            <div class="single-product">
                <div class="product-image">
                    <img src="<?php echo $val["path"]?>">
                    <?php if($val["Discound"] >0)
                    {
                        ?>
                            <span class="sale-tag"><?php echo $val["Discound"] ?>  %</span>
                        <?php
                    }
                    ?>
                </div>
                <div class="product-info">
                    <center>
                    <h4 class="title">
                        
                        <a href="#"><?php echo $val["name"];
                        if(!($tb=="electronic" || $tb=="watch"))echo $val["memory_"] ?></a>
                    </h4>
                    </center>
                    <center>
                    <ul class="review">
                        <li><i class="lni lni-star-filled"></i></li>
                        <li><i class="lni lni-star-filled"></i></li>
                        <li><i class="lni lni-star-filled"></i></li>
                        <li><i class="lni lni-star-filled"></i></li>
                        <li><i class="lni lni-star"></i></li>
                        <li><span>4.0 Review(s)</span></li>
                    </ul>
                    </center>
                    <center>
                    <div class="price">
                       
                        <?php if($val["Discound"] >0)
                    {
                        ?>
                         <span id="AED"><?php echo $val["price_new"]; echo $GLOBALS['langage']["language"] ?> </span>
                        <span class="discount-price"><?php echo $val["price_old"]; echo $GLOBALS['langage']["language"] ?> </span>
                        <?php
                    }
                    else
                    {
                        ?>
                    <span id="AED"><?php echo $val["price_old"];echo $GLOBALS['langage']["language"] ?> </span>
                        <?php
                    }
                       ?> 
                    </div>
                    <br>
                    
                    <a href="information.php?id=<?php echo $val["Id"]?>&name=<?php echo $val["name"]?>&detial=<?php echo $val["Discribtion"]?>&path=<?php echo $val["path"]?>&old=<?php echo $val["price_old"]?>&new=<?php echo $val["price_new"]?>&tbb=<?php echo $tb ?>" class="pay">شراء </a>
                </center>
                </div>
            </div>
        </div>

        <?php 
                }
            }
            ?>
                        <center>
            <div style="background-color: #fffffff5; margin: 10px;" >
                <a href="allItem.php?tb=<?php echo $tb; ?>" class="pay"> عرض المزيد</a>
            </div>
        </center>
            <?php
}
}
if(isset($_POST["main"]))
{
GetRowss("iphone_e","","قسم الايفونات","Iphone");
GetRowss("samsung_e","","قسم السامسونج","samsung");
GetRowss("huawei_e","","قسم الهواوي","huawei");
GetRowss("hande_e","","قسم السماعات","handphones");
GetRowss("laptop_e","","قسم الاب توبات","laptop");
GetRowss("electronic","","قسم الاجهزة","electronic");
GetRowss("watch","","قسم الساعات","watch");
}
/////////////////////////////////////////////
function GETAll($tb,$str)
{
    $db = new Database();
    $count = $db->getCount("SELECT count(*) from $tb");
    if($tb=="electronic" || $tb=="watch")
    {
        $selet = $db->GetRows("SELECT Id,path,name,number_,price_old,price_new,Discound,Discribtion from $tb order by number_ desc limit $str,8 ");
    }
    else
    {
    $selet = $db->GetRows("SELECT Id,path,name,number_,price_old,price_new,memory_,Discound,Discribtion from $tb order by number_ desc limit $str,8 ");
    }
    if(count($selet)){
     foreach($selet as $val) { 
        if(intval($val["number_"] >0)){
        ?>
        <div class="col-lg-3 col-md-6 col-12" id="respon">
            <div class="single-product">
                <div class="product-image">
                    <img src="<?php echo $val["path"]?>">
                    <?php if($val["Discound"] >0)
                    {
                        ?>
                            <span class="sale-tag"><?php echo $val["Discound"] ?>  %</span>
                        <?php
                    }
                    ?>
                </div>
                <div class="product-info">
                    <center>
                    <h4 class="title">
                        
                        <a href="#"><?php echo $val["name"];if(!($tb=="electronic" || $tb=="watch")) echo $val["memory_"] ?></a>
                    </h4>
                    </center>
                    <center>
                    <ul class="review">
                        <li><i class="lni lni-star-filled"></i></li>
                        <li><i class="lni lni-star-filled"></i></li>
                        <li><i class="lni lni-star-filled"></i></li>
                        <li><i class="lni lni-star-filled"></i></li>
                        <li><i class="lni lni-star"></i></li>
                        <li><span>4.0 Review(s)</span></li>
                    </ul>
                    </center>
                    <center>
                    <div class="price">

                        <?php if($val["Discound"] >0)
                    {
                        ?>
                        <span id="AED"><?php echo $val["price_new"];echo $GLOBALS['langage']["language"] ?> </span>
                        <span class="discount-price"><?php echo $val["price_old"]; echo $GLOBALS['langage']["language"] ?> </span>
                        <?php
                    }
                    else
                    {
                        ?>
                    <span id="AED"><?php echo $val["price_old"];echo $GLOBALS['langage']["language"] ?> </span>
                        <?php
                    }
                       ?> 
                    </div>
                    <br>
                    
                    <a href="information.php?id=<?php echo $val["Id"]?>&name=<?php echo $val["name"]?>&detial=<?php echo $val["Discribtion"]?>&path=<?php echo $val["path"]?>&old=<?php echo $val["price_old"]?>&new=<?php echo $val["price_new"]?>&tbb=<?php echo $tb ?>" class="pay">شراء </a>
                </center>
                </div>
            </div>
        </div>

        <?php 
                }
            }
}
$num=$count/8;
if($num>1){
 ?>
 <script>
     document.getElementById("all_item").innerHTML="";
 </script>
 <?php
for($i=0;$i<$num;$i++) 
{?>
<script>
document.getElementById("all_item").innerHTML+="<div class='_num' id='next' onclick='GoNext_item(<?php echo $i ?>)'><?php echo $i ?></div>";
</script>

<?php
}
}
}
















if(isset($_POST["allitem"]))
{
    GETAll($_POST["tabel"],0);  
}
if(isset($_POST["next"]))
{
    $start=intval($_POST["next"]);
    $str=($start*8);
    if($start==0) $str=0;
    $end=intval(($start+1)*8);
    GETAll($_POST["tabel"],$str);
} 
if(isset($_POST["input"]))
{

    $db = new Database();
    $input=$_POST["input"];
    if($_POST['tabel']=="electronic" || $_POST['tabel']=="watch")
    {
        $selet = $db->GetRows("SELECT Id,path,name,number_,price_old,price_new,Discound,Discribtion from $_POST[tabel] where name like '{$input}%' Or price_old like '{$input}%' Or price_new like '{$input}%'  Or number_ like '{$input}%'");
    }
    else
    {
    $selet = $db->GetRows("SELECT Id,path,name,number_,price_old,price_new,memory_,Discound,Discribtion from $_POST[tabel] where name like '{$input}%' Or price_old like '{$input}%' Or price_new like '{$input}%' Or memory_ like '{$input}%' Or number_ like '{$input}%'");
    }
    if(count($selet)){
        ?>
            <script>
            document.getElementById("all_item").innerHTML="";
        </script>
        <?php
     foreach($selet as $val) { 
        if(intval($val["number_"] >0)){
        ?>
        <div class="col-lg-3 col-md-6 col-12" id="respon">
            <div class="single-product">
                <div class="product-image">
                    <img src="<?php echo $val["path"]?>">
                    <?php if($val["Discound"] >0)
                    {
                        ?>
                            <span class="sale-tag"><?php echo $val["Discound"] ?>  %</span>
                        <?php
                    }
                    ?>
                </div>
                <div class="product-info">
                    <center>
                    <h4 class="title">
                        
                        <a href="#"><?php echo $val["name"];if(!($_POST['tabel']=="electronic" || $_POST['tabel']=="watch")) echo $val["memory_"] ?></a>
                    </h4>
                    </center>
                    <center>
                    <ul class="review">
                        <li><i class="lni lni-star-filled"></i></li>
                        <li><i class="lni lni-star-filled"></i></li>
                        <li><i class="lni lni-star-filled"></i></li>
                        <li><i class="lni lni-star-filled"></i></li>
                        <li><i class="lni lni-star"></i></li>
                        <li><span>4.0 Review(s)</span></li>
                    </ul>
                    </center>
                    <center>
                    <div class="price">
                        <?php if($val["Discound"] >0)
                    {
                        ?>
                        <span id="AED"><?php echo $val["price_new"];echo $GLOBALS['langage']["language"] ?> </span>
                        <span class="discount-price"><?php echo $val["price_old"];echo $GLOBALS['langage']["language"] ?> </span>
                        <?php
                    }
                    else
                    {
                        ?>
                        <span id="AED"><?php echo $val["price_old"];echo $GLOBALS['langage']["language"] ?> </span>
                        <?php
                    }
                       ?> 
                    </div>
                    <br>
                    
                    <a href="information.php?id=<?php echo $val["Id"]?>&name=<?php echo $val["name"]?>&detial=<?php echo $val["Discribtion"]?>&path=<?php echo $val["path"]?>&old=<?php echo $val["price_old"]?>&new=<?php echo $val["price_new"]?>&tbb=<?php echo $tb ?>" class="pay">شراء </a>
                </center>
                </div>
            </div>
        </div>

        <?php 
                }
            }
}
}
// /////////////////////////
function Orderrr()
{
    $db = new Database();

        $selet_order = $db->GetRows("SELECT * from order_client_register where email_user='$_SESSION[user]'");
        $Max_Min = $db->GetRow("SELECT SUM(price_after) as sum1,SUM(pric_before) as sum  from order_client_register where email_user='$_SESSION[user]'");

    
        foreach($selet_order as $val) 
        {
            $order_info = $db->GetRow("SELECT Id,path,name,price_old,price_new,number_ from $val[tb_name] where Id =$val[id_order] "); 
            ?>
    <tr class="alert" role="alert">
    <td>
    <label class="checkbox-wrap checkbox-primary">
    <input type="checkbox" checked>
    <span class="checkmark"></span>
    </label>
    </td>
    <td class="d-flex align-items-center">
    <div class="img" style="background-image: url(<?php echo $order_info["path"] ?>);"></div>
    <div class="pl-3 email">
    <span>Name :<?php echo $order_info["name"] ?></span>
    </div>
    </td>
    <td><?php echo $val["count"]  ?></td>
    <td><?php echo($val['price_after']) ?></td>
    <td><?php echo($val['pric_before']) ?> </td>
    <?php
    if($val["checkk"]==1)
    {
        ?>
        <td><a class="link" ><i class="fa fa-check" id="unlock"></i> </a></td>
        <td><a class="link" > </a></td>
        <?php
    }
    else
    {
        ?>
        <td><a class="link" ><i class="fa fa-close" id="unlock"></i> </a></td>
        <td><a class="link" onclick="Deleting_from_order(<?php echo $val['Id']?>)"><i class="fa fa-trash-o" id="unlock"></i></a></td>
        <?php
    }
    ?>

    
    
    </tr>
        <?php
        }
        ?>
        <tr  style="box-shadow: 2px 3px 10px -1px;">
        <td colspan="3" >Total</td>
        <td ><?php echo $Max_Min['sum1'] ?></td>
        <td ><?php echo $Max_Min['sum'] ?></td>
        </tr>
        <?php
}
if(isset($_POST["order_item"]))
{
    Orderrr();
    
}
if(isset($_POST['order_del']))
{

    $db = new Database();
    $id=intval($_POST["Deleting_order"]);
        $del = $db->Delete("DELETE FROM order_client_register WHERE Id=$id");
    Orderrr();
}

///////////////
?>