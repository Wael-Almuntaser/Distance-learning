<?php
session_start();
require_once "../assets/dataBase/allTabel.php";
$db = new Database();
$iddd=intval($_GET["id"]);
    if(isset($_SESSION["user"]))
    {
        $del = $db->Delete("DELETE FROM order_client_register WHERE Id= $iddd");
    }
    if(isset($_SESSION["temp_user"]))
    {
        $del = $db->Delete("DELETE FROM orderr WHERE Id=$iddd");
        unset($_SESSION['temp_user']);
    }
    
    
?>
<script>window.location = "index.php";</script>