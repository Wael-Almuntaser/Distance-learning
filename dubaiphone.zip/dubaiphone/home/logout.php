<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
session_destroy();
session_unset();
unset($_SESSION);
?>
<script>
    window.location = "index.php";
</script>
<?php

?>