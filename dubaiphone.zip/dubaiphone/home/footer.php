
<footer class="footer">
<div class="footer-middle">
    <div class="container">
        <div class="bottom-inner">
            <div class="row">
                <div class="col-lg-3 col-md-6 col-12">
                    <!-- Single Widget -->
                    <div class="single-footer f-contact">
                        <h3>تفاصيل عنا</h3>
                        <p class="phone"><?php echo $social["number"]  ?></p>
                        <ul>
                            <li><span>Monday-Friday: </span> 9.00 am - 8.00 pm</li>
                            <li><span>Saturday: </span> 10.00 am - 6.00 pm</li>
                        </ul>
                        <p class="mail">
                            <a href="mailto:support@shopgrids.com"><?php echo $social["email"]  ?></a>
                        </p>
                    </div>
                    <!-- End Single Widget -->
                </div>
                <div class="col-lg-3 col-md-6 col-12">
                    <!-- Single Widget -->
                    <!-- End Single Widget -->
                </div>
                <div class="col-lg-3 col-md-6 col-12">
                    <!-- Single Widget -->
                    <div class="single-footer f-link">
                        <h3>معلومات</h3>
                        <ul>
                            <li><a href="#">من نحن</a></li>
                            <li><a href="#">تواصل معنا</a></li>
                            <!-- <li><a href="#">Sitemap</a></li> -->
                        </ul>
                    </div>
                    <!-- End Single Widget -->
                </div>
                <div class="col-lg-3 col-md-6 col-12">
                    <!-- Single Widget -->
                    <div class="single-footer f-link">
                        <h3>محتويات المتجر</h3>
                        <ul>
                            <li><a href="allItem.php?tb=iphone_e">الايفونات</a></li>
                            <li><a href="allItem.php?tb=samsung_e">السامسونج</a></li>
                            <li><a href="allItem.php?tb=huawei_e">هواوي</a></li>
                            <li><a href="allItem.php?tb=hande_e">السماعات</a></li>
                            <li><a href="allItem.php?tb=laptop_e">الاجهزة</a></li>
                            <li><a href="allItem.php?tb=electronic">اجهزه</a></li>
                            <li><a href="allItem.php?tb=watch">ساعات</a></li>
                        </ul>
                    </div>
                    <!-- End Single Widget -->
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Start Footer Bottom -->
<div class="footer-bottom">
    <div class="container">
        <div class="inner-content">
            <div class="row align-items-center">
                <div class="col-lg-4 col-12">
                    <div class="payment-gateway">
                        <span>الايداع عبر :</span>
                        <img src="../assets/images/footer/credit-cards-footer.png" alt="#">
                    </div>
                </div>
                <div class="col-lg-4 col-12">
                    <div class="copyright">
                        <p>تصميم وتطوير بواسطه المهندس <a href="https://graygrids.com/" rel="nofollow"
                                target="_blank">ٍٍٍٍسلطان الجعامي</a></p>
                    </div>
                </div>
                <div class="col-lg-4 col-12">
                    <ul class="socila">
                        <li>
                            <span>تواصل معنا عبر :</span>
                        </li>
                        <li><a href="<?php echo $social["face_book"]  ?>"><i class="lni lni-facebook-filled"></i></a></li>
                        <li><a href="<?php echo $social["tiwiter"]  ?>"><i class="lni lni-twitter-original"></i></a></li>
                        <li><a href="<?php echo $social["instagram"]  ?>"><i class="lni lni-instagram"></i></a></li>
                        <li><a href="<?php echo $social["sky"]  ?>"><i class="lni lni-skype"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
</footer>

