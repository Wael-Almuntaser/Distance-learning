<?php

session_start();
require_once "../assets/dataBase/allTabel.php";
$db = new Database();
$social = $db->GetRow("SELECT * from icon_num limit 1");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8" />
    <meta http-equiv="x-ua-compatible" content="ie=edge" />
    <meta name="description" content="" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.svg" />

    <!-- ========================= CSS here ========================= -->
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css" />
    <link rel="stylesheet" href="../assets/css/LineIcons.3.0.css" />
    <link rel="stylesheet" href="../assets/css/tiny-slider.css" />
    <link rel="stylesheet" href="../assets/css/glightbox.min.css" />
    <link rel="stylesheet" href="../assets/css/main.css" />
    <link rel="stylesheet" href="../assets/css/login_and_register.css" />
    <script src="../assets/js/jquery.js"></script>
</head>

<body style="direction: rtl;">

<header class="header navbar-area">
        <!-- Start Topbar -->
        <div class="topbar">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-4 col-md-4 col-12">
                        <div class="top-left">
                            <ul class="menu-top-link">
                                <li>
                                    <div class="select-position">
                                        <select id="select5">
                                            <option value="4">English</option>
                                        </select>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-12">
                        <div class="top-middle">
                            <ul class="useful-links">
                                <li><a href="index.php">الرئيسية</a></li>
                                <li><a href="?">من نحن</a></li>
                                <li><a href="?">تواصل معنا</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-12">
                        <div class="top-end">
                            <!--  -->
                            <?php if(isset($_SESSION['user'])){ ?>
                            <div class="user-login">
                                <i class="lni lni-user"></i>
                                <li>
                                    <a href="../home/dashbord.php">مرحبا</a>
                                </li>
                                <li>
                                    <a href="../home/logoutt.php">تسجيل الخروج</a>
                                </li>
                                <!-- <i class="lni lni-user"></i> -->
                            </div>
                            <?php }
                            else {
                            ?>
                            <!--  -->
                            <ul class="user-login">
                                <li>
                                    <a href="../home/login.php">تسجيل الدخول</a>
                                </li>
                                <li>
                                    <a href="../home/register.php">انشاء حساب</a>
                                </li>
                            </ul>
                            <?php  } ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="header-middle" id="container___">
                            <a class="navbar-brand" href="index.php">
                                <img src="<?php echo $social["icon"]  ?>" alt="Logo">
                            </a>
                            <div class="nav-hotline">
                                <i class="lni lni-phone"></i>
                                <h3>Hotline:
                                    <span><?php echo $social["number"]  ?></span>
                                </h3>
                                
                            </div>
                            <div class="navbar-cart">
                                <div class="wishlist">
                                    <a href="javascript:void(0)">
                                        <i class="lni lni-heart"></i>
                                        <span class="total-items">0</span>
                                    </a>
                                </div>
                                <div class="cart-items">
                                    <a href="javascript:void(0)" class="main-btn">
                                        <i class="lni lni-cart"></i>
                                        <span class="total-items">
                                        <?php 
                                        if(isset($_SESSION['user']))
                                        {
                                        $count = $db->getCount("SELECT count(email_user) from order_client_register where email_user='$_SESSION[user]' and sure=0 ");
                                        echo $count;
                                        }
                                        if(isset($_SESSION['temp_user']))
                                        {
                                            $count = $db->getCount("SELECT count(email) from orderr where email='$_SESSION[temp_user]' and sure=0 "); 
                                            echo $count;
                                        }
                                         
                                          ?></span>
                                    </a>
                                    <!-- Shopping Item -->
                                    <?php if(isset($_SESSION['user']) || isset($_SESSION["temp_user"]))
                                    { ?>
                                    <div class="shopping-item">
                                        <div class="dropdown-cart-header">
                                            <a href="?">الطلبات</a>
                                        </div>
                                        <ul class="shopping-list">
                                            <?php
                                            if(isset($_SESSION['user'])){
                                                    $selet_order = $db->GetRows("SELECT * from order_client_register where email_user='$_SESSION[user]'  and sure=0");
                                                    $Max_Min = $db->GetRow("SELECT SUM(pric_before) as sum  from order_client_register where email_user='$_SESSION[user]' and sure=0");
                                                    foreach($selet_order as $val) 
                                                    {
                                                        $order_info = $db->GetRow("SELECT Id,path,name,price_old,price_new from $val[tb_name] where Id =$val[id_order] "); 
                                                        
                                                    
                                            ?>
                                            <li>
                                                <a href="delete_list.php?id=<?php echo $val['Id'] ?>" class="remove" title="Remove this item" onclick="deletefromitem()"><i
                                                        class="lni lni-close"></i></a>
                                                <div class="cart-img-head">
                                                    <a class="cart-img" href="#"><img
                                                            src="<?php echo $order_info["path"] ?>" alt="#"></a>
                                                </div>

                                                <div class="content">
                                                    <h4><a href="#">
                                                    "<?php echo $order_info["name"] ?>"</a></h4>
                                                    <p class="quantity"><?php echo $val['count'] ?> - <span class="amount"><?php echo $val['pric_before'] ?></span></p>
                                                </div>
                                            </li>
                                            <?php
                                                }    
                                            }   
                                            else
                                            {
                                                $selet_order = $db->GetRows("SELECT * from orderr where email='$_SESSION[temp_user]'  and sure=0");
                                                $Max_Min = $db->GetRow("SELECT SUM(pric_before) as sum  from orderr where email='$_SESSION[temp_user]' and sure=0");
                                                foreach($selet_order as $val) 
                                                {
                                                    $order_info = $db->GetRow("SELECT Id,path,name,price_old,price_new from $val[tb_name] where Id =$val[id_order] "); 
                                                    
                                                
                                        ?>
                                        <li>
                                            <a href="delete_list.php?id=<?php echo $val['Id'] ?>" class="remove" title="Remove this item" ><i
                                                    class="lni lni-close"></i></a>
                                            <div class="cart-img-head">
                                                <a class="cart-img" href="#"><img
                                                        src="<?php echo $order_info["path"] ?>" alt="#"></a>
                                            </div>

                                            <div class="content">
                                                <h4><a href="#">
                                                "<?php echo $order_info["name"] ?>"</a></h4>
                                                <p class="quantity"><?php echo $val['count'] ?> - <span class="amount"><?php echo $val['pric_before'] ?></span></p>
                                            </div>
                                        </li>
                                        <?php
                                            }
                                            }     
                                            ?>
<!--  -->
                                        </ul>
                                        <div class="bottom">
                                            <div class="total">
                                                <span>الاجمالي</span>
                                                <span class="total-amount"><?php echo $Max_Min['sum'] ?></span>
                                            </div>
                                            <div class="button">
                                                <a href="checkout.php" class="btn animate">تاكيد الطلب</a>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                            }
                                    ?>
                                    <!--/ End Shopping Item -->
                                </div>
                            </div>
                        <!-- </div> -->
                    <!-- </div> -->
                <!-- </div> -->
            <!-- </div> -->
        </div>
        <!-- End Header Middle -->
        <!-- Start Header Bottom -->
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-8 col-md-6 col-12">
                    <div class="nav-inner">
                        <!-- Start Mega Category Menu -->
                        <div class="mega-category-menu">
                            <span class="cat-button"><i class="lni lni-menu"></i>جميع الاصناف</span>
                            <ul class="sub-category">
                                <li><a href="allItem.php?tb=iphone_e">ايفونات</a></li>
                                <li><a href="allItem.php?tb=samsung_e">سامسونج</a></li>
                                <li><a href="allItem.php?tb=huawei_e">هواوي</a></li>
                                <li><a href="allItem.php?tb=hande_e">سماعات</a></li>
                                <li><a href="allItem.php?tb=laptop_e">لابتوبات</a></li>
                                <li><a href="allItem.php?tb=electronic">اجهزه</a></li>
                                <li><a href="allItem.php?tb=watch">ساعات</a></li>
                            </ul>
                        </div>
                        <!-- End Mega Category Menu -->
                        <!-- Start Navbar -->
                        <nav class="navbar navbar-expand-lg">
                            <button class="navbar-toggler mobile-menu-btn" type="button" data-bs-toggle="collapse"
                                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                                aria-expanded="false" aria-label="Toggle navigation">
                                <span class="toggler-icon"></span>
                                <span class="toggler-icon"></span>
                                <span class="toggler-icon"></span>
                            </button>
                            <div class="collapse navbar-collapse sub-menu-bar" id="navbarSupportedContent">
                                <ul id="nav" class="navbar-nav ms-auto">
                                    <li class="nav-item">
                                        <a href="index.php" class="active" aria-label="Toggle navigation">الرئيسية</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="dd-menu collapsed" href="javascript:void(0)" data-bs-toggle="collapse"
                                            data-bs-target="#submenu-1-2" aria-controls="navbarSupportedContent"
                                            aria-expanded="false" aria-label="Toggle navigation">الصفحات</a>
                                        <ul class="sub-menu collapse" id="submenu-1-2">
                                            <li class="nav-item"><a href="allItem.php?tb=iphone_e">ايفونات</a></li>
                                            <li class="nav-item"><a href="allItem.php?tb=samsung_e">سامسونج</a></li>
                                            <li class="nav-item"><a href="allItem.php?tb=huawei_e">هواوي</a></li>
                                            <li class="nav-item"><a href="allItem.php?tb=hande_e">سماعات</a></li>
                                            <li class="nav-item"><a href="allItem.php?tb=laptop_e">لابتوبات</a></li>
                                            <li class="nav-item"><a href="allItem.php?tb=electronic">الاجهزة</a></li>
                                            <li class="nav-item"><a href="allItem.php?tb=watch">ساعات</a></li>
                                        </ul>
                                    </li>
                                    <li class="nav-item">
                                        <a class="dd-menu collapsed" href="javascript:void(0)" data-bs-toggle="collapse"
                                            data-bs-target="#submenu-1-3" aria-controls="navbarSupportedContent"
                                            aria-expanded="false" aria-label="Toggle navigation">المتجر</a>
                                        <ul class="sub-menu collapse" id="submenu-1-3">
                                            <li class="nav-item"><a href="#">المتجر</a></li>
                                        </ul>
                                    </li>
                                    <li class="nav-item">
                                        <a href="#" aria-label="Toggle navigation">تواصل معنا</a>
                                    </li>
                                </ul>
                            </div> <!-- navbar collapse -->
                        </nav>
                        <!-- End Navbar -->
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-12">
                    <!-- Start Nav Social -->
                    <div class="nav-social">
                    
                        <h5 class="title">:مواقعنا</h5>
                        <ul>
                            <li>
                                <a href="<?php echo $social["face_book"]  ?>"><i class="lni lni-facebook-filled"></i></a>
                            </li>
                            <li>
                                <a href="<?php echo $social["tiwiter"]  ?>"><i class="lni lni-twitter-original"></i></a>
                            </li>
                            <li>
                                <a href="<?php echo $social["instagram"]  ?>"><i class="lni lni-instagram"></i></a>
                            </li>
                            <li>
                                <a href="<?php echo $social["sky"]  ?>"><i class="lni lni-skype"></i></a>
                                <a href="<?php echo $social["whats"]  ?>" id="whatsapp"><i class="lni lni-whatsapp" style="font-size:63px; color:green"></i></a>
                            </li>
                        </ul>
                        
                    </div>
                    <!-- End Nav Social -->
                </div>
            </div>
        </div>
        

</body>
</html>
<script src="../assets/js/jquery.js"></script>
<script>

</script>