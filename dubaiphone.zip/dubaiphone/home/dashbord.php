<?php
include "header_user.php";
$order = $db->getCount("SELECT count(*) from order_client_register where email_user='$_SESSION[user]'");
$accept_order = $db->getCount("SELECT count(*) from order_client_register where email_user='$_SESSION[user]' and checkk=1");
$decline_order = $db->getCount("SELECT count(*) from order_client_register where email_user='$_SESSION[user]' and checkk=0");
?>

<div class="w3-row-padding w3-margin-bottom">
    <div class="w3-quarter">
      <div class="w3-container w3-blue w3-padding-16">
        <div class="w3-left"><i class="fa fa-comment w3-xxxlarge"></i></div>
        <div class="w3-right">
          <h3><?php echo $order ?></h3>
        </div>
        <div class="w3-clear"></div>
        <h6>الطلبات</h6>
      </div>
    </div>
    <div class="w3-quarter">
      <div class="w3-container w3-teal w3-padding-16">
        <div class="w3-left"><i class="fa fa-eye w3-xxxlarge"></i></div>
        <div class="w3-right">
          <h3><?php echo $accept_order ?></h3>
        </div>
        <div class="w3-clear"></div>
        <h6>الطلبات المقبولة</h6>
      </div>
    </div>
    <div class="w3-quarter">
      <div class="w3-container w3-red w3-padding-16">
        <div class="w3-left"><i class="fa fa-warning"></i></div>
        <div class="w3-right">
          <h3><?php echo $decline_order ?></h3>
        </div>
        <div class="w3-clear"></div>
        <h6>الطلبات المرفوضة</h6>
      </div>
    </div>
  </div>




<?php
include "footer_user.php";
?>
