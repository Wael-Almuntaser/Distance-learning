<?php
include "header.php"
?>

<section class="trending-product section" style="margin-top: 12px;">
<center>
                    <div class="col-lg-5 col-md-7 d-xs-none">
                        
                        <div class="main-menu-search">
                            
                            <div class="navbar-search search-style-5">
                                <div class="search-select">
                                    <div class="select-position">
                                        <select id="select1">
                                            <option selected><?php $t= explode("_",$_GET['tb']); echo $t[0]; ?></option>
                                        </select>
                                    </div>
                                </div>
                                <div class="search-input">
                                    <input type="text" placeholder="البحث" id="live_search">
                                </div>
                            </div>
                            
                        </div>
                         
                    </div>
</center>
<div class="container">
<div class="row" id="searchResult">
                
                </div>
<div class="Con_num" id="all_item"></div>
</div>
</section>

<?php
include "footer.php"
?>
<script src="../assets/js/jquery.js"></script>
<script type="text/javascript">
    $(document).ready(function()
    {   
        var allitem="allitem";
        var tabel="<?php echo $_GET['tb'] ?>";
        $.ajax({
            url:"show_index.php",
            data:
            {allitem:allitem,
                tabel:tabel,},
            method:"post",
            success:function(data)
            {
                $("#searchResult").html(data);
            }
        });
        // seacrh
        $("#live_search").keyup(function()
        {
            var input=$(this).val();
            var tabel="<?php echo $_GET['tb'] ?>";
            if(input !="")
            {
                $("#searchResult").css("display","flex");
                $.ajax({
                    url:"show_index.php",
                    method:"post",
                    data:{input : input,
                        tabel:tabel, },
                    success:function(data)
                    {
                        $("#searchResult").html(data);
                    }
                });
            }
            else
            {
            var allitem="allitem";
            var tabel="<?php echo $_GET['tb'] ?>";
            $.ajax({
            url:"show_index.php",
            data:
            {allitem:allitem,
                tabel:tabel,},
            method:"post",
            success:function(data)
            {
                $("#searchResult").html(data);
            }
        });
            }
        });

        ///

    });




    function GoNext_item(params)
    {
        var next=params;
        var tabel="<?php echo $_GET['tb'] ?>";
        $.ajax({
            url:"show_index.php",
            data:
            {next:next,
                tabel:tabel,},
            method:"post",
            success:function(data)
            {
                $("#searchResult").html(data);
            }
        });
    }
    </script>