<?php
include "header.php";
if(isset($_SESSION['user']))
{
    ?>
    <script>window.location = "index.php";</script>
    <?php
}
?>
  <div class="container_R" id="container_l">
  <div id="error" class="alert alert-danger alert-dismissible fade show w-100" role="alert"></div>
    <div class="forms">
        <div class="form-content">
          <div class="login-form">
            <div class="title">تسجيل الدخول</div>
          <form action="#" id="sample_form" method="post">
          <div class="user-details">
                <div class="input-boxx">
                    <span class="details">الايميل</span>
                    <input type="email" placeholder="ادخل الايميل " id="email" name="email">
                  </div>
                  <div class="input-boxx">
                    <span class="details">كلمة السر</span>
                    <input type="password" placeholder="ادخل كلمة السر" id="password" name="password" >
                  </div>
                  <input type="hidden" id="login" name="login" value="login">
              <div class="text"><a href="forgetpasswor.php">نسيت كلمه السر?</a></div>
              <div class="button">
                <input type="submit" id="submit" name="submit" value="تسجيل دخول">
              </div>
              <div class="text sign-up-text">ليس لدي حساب? <a href="register.php">انشاء حساب</a></div>
</div>
        </form>
        <div class="preloader-inner" id="preloader_1">
          <div class="preloader-icon">
              <span></span>
              <span></span>
          </div>
      </div>
      </div>
    </div>
    </div>
  </div>

  <?php
include "footer.php"
?>
<script>
  $(document).ready(function(){
    $("#preloader_1").hide();
    $("#error").hide();
    $('#sample_form').on('submit', function(event){
      event.preventDefault();
        $.ajax({
          url : "../assets/dataBase/UserDB.php",
          method:"POST",
          data: new FormData(this),
          contentType:false,
          cache:false,
          processData:false,
          success: function(response){
            if(response == 1){
              $("#preloader_1").show();
              $("#error").removeClass("alert-danger");
              $("#error").addClass("alert-primary");
              $("#error").show().html("جاري تنفيذ العملية");
              setInterval(function () {
             window.location = "index.php";
              }, 2000);
           
               
            }
            else{
             $("#error").show().html(response);
            }
					}
        })  
    
      
        return false;
    })
  })

</script>