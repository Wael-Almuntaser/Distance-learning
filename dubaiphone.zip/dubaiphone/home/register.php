<?php
include "header.php";
if(isset($_SESSION['user']))
{
    ?>
    <script>window.location = "index.php";</script>
    <?php
}
?>
<div class="container_R">


    <div id="error" class="alert alert-danger alert-dismissible fade show w-100" role="alert"></div>

    <div class="title">إنشاء حساب</div>
    <div class="content">
      <form action="#" id="sample_form" method="post">
        <div class="user-details">
          <div class="input-box">
            <span class="details">الاسم كامل</span>
            <input type="text" placeholder="ادخل الاسم كاملاً" id="name"  name="name"  >
          </div>
          <div class="input-box">
            <span class="details">اسم المستخدم</span>
            <input type="text" placeholder="ادخل اسم المستخدم" id="username" name="username" >
          </div>
                    <div class="input-box">
            <span class="details">الايميل</span>
            <input type="email" placeholder="ادخل الايميل" id="email" name="email" >
          </div>
          <div class="input-box">
            <span class="details">رقم الهاتف</span>
            <input type="number" placeholder="ادخل رقم الهاتف" id="phone" name="phone" >
          </div>
          <div class="input-box">
            <span class="details">كلة السر</span>
            <input type="password" placeholder="ادخل كلمة السر" id="password" name="password" >
          </div>
          <div class="input-box">
            <span class="details">تاكيد كلمة السر </span>
            <input type="password" placeholder="اكد كلمة المرور" id="Confpassword" name="Confpassword" >
          </div>
          <input type="hidden" id="create" name="create" value="create>
        </div>
    <div class="button_">
        <span>هل لديك حساب </span><a href="login.php">تسجيل الدخول</a>
      </div>
      <div class="button">
        <input type="submit" id="submit" name="submit"  value="إنشاء حساب">
      </div>
</form>
<div class="preloader-inner" id="preloader_1">
    <div class="preloader-icon">
        <span></span>
        <span></span>
    </div>
</div>
</div>
</div>



<script>
  $(document).ready(function(){
    $("#preloader_1").hide();
    $("#error").hide();
    $('#sample_form').on('submit', function(event){
      event.preventDefault();
        $.ajax({
          url : "../assets/dataBase/UserDB.php",
          method:"POST",
          data: new FormData(this),
          contentType:false,
          cache:false,
          processData:false,
          success: function(response){
            if(response == 1){
              $("#preloader_1").show();
              $("#error").removeClass("alert-danger");
              $("#error").addClass("alert-primary");
              $("#error").show().html("جاري التنفيذ");
              setInterval(function () {
             window.location = "login.php";
              }, 2000);
           
               
            }
            else{
             $("#error").show().html(response);
            }
					}
        })  
    
      
        return false;
    })
  })

</script>

