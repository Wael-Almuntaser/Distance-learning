<?php
include "header_user.php";

?>
<style>
    div#bbbbbb {
    padding: 39px 7px;
    background-color: white;
    box-shadow: 6px 9px 9px 26px 5px black;
    margin: 60px auto;
    box-shadow: 2px 3px 10px -1px;
    overflow-x: auto;
}
.KKKKM {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 30px;
}
span
{
    font-weight: bold;
}
</style>
<!doctype html>
<html lang="en">
	<body>
	<section class="ftco-section">
		<div class="container">
			<div class="row">
				<div class="col-md-12" id="bbbbbb">
					<div class="table-wrap">
                        <!--  -->
                        
                        <!--  -->
                        
						<table class="table table-responsive-xl">
                        
						  <thead>
						    <tr>
						    	<th>&nbsp;</th>
						      <th>image</th>
                              <th>number</th>
                              <th>Price_before</th>
                              <th>Price_after</th>
                              <th>Accept</th>
                              <th>Delete</th>

						    </tr>
						  </thead>
						  <tbody id="order_item">
						    
						  </tbody>
     
						</table>
					</div>
				</div>
			</div>
		</div>
	</section>


	</body>
</html>

<script src="../assets/js/jquery.js"></script>
<script type="text/javascript">
    $(document).ready(function()
    {  $("#error").hide();
        var order_item="order_item";
        $.ajax({
            url:"show_index.php",
            data:
            {order_item:order_item},
            method:"post",
            success:function(data)
            {
                $("#order_item").html(data);
            }
        });
    });
    function Deleting_from_order(e,p)
    {
        var Deleting_order=e;
        var order_del="order_del";
        $.ajax({
            url:"show_index.php",
            data:
            {Deleting_order:Deleting_order,
                order_del:order_del,
            },
            method:"post",
            success:function(data)
            {
                $("#order_item").html(data);
            }
        });
    }


//  <!-- /////////////////////////////////////////    Update Lock And Not Lock////////////////////// -->

</script>
</body>
</html>











<?php
include "footer_user.php"; 
?>