<?php
include "header.php"
?>
    <section class="hero-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-12 custom-padding-right">
                    <div class="slider-head">
                        <!-- Start Hero Slider -->
                        <div class="hero-slider">
                            <!-- Start Single Slider -->
                            <?php
                            $db = new Database();
                            $selet = $db->GetRows("SELECT Id,photo,header_1,header_2,price,detail from news");
                            foreach($selet as $val) 
                            { ?>
                                <div class="single-slider"
                                style="background-image: url('<?php echo $val['photo'] ?>');">
                                <div class="content">
                                    <h2><span><?php echo $val['header_1'] ?></span>
                                    <?php echo $val['header_2'] ?>
                                    </h2>
                                    <p><?php echo $val['detail'] ?></p>
                                    <h3><span>السعر</span><?php echo $val['price'] ?></h3>
                                    <div class="button">
                                        <a href="#" class="btn">تسوق الان</a>
                                    </div>
                                </div>
                            </div>
                            <?php

                            }
                        ?>

                            <!-- End Single Slider -->
                            <!-- Start Single Slider -->

                            <!-- End Single Slider -->
                        </div>
                        <!-- End Hero Slider -->
                    </div>
                </div>
                <div class="col-lg-4 col-12">
                    <div class="row">
                        <div class="col-lg-12 col-md-6 col-12 md-custom-padding">
                            <!-- Start Small Banner -->
                            <?php 
                                    $db = new Database();
                                    $selet__ = $db->GetRow("SELECT Id,photo,header_1,header_2,price from news  limit 1");
                                    ?>
                            <div class="hero-small-banner"
                                style="background-image: url('<?php echo $selet__["photo"]?>');">
                                <div class="content">

                                    <h2>
                                        <span><?php echo $selet__["header_1"]?></span>
                                        <?php echo $selet__["header_2"]?>
                                    </h2>
                                    <h3><?php echo $selet__["price"]?></h3>
                                </div>
                            </div>
                            <!-- End Small Banner -->
                        </div>
                        <div class="col-lg-12 col-md-6 col-12">
                            <!-- Start Small Banner -->
                            <div class="hero-small-banner style2">
                                <div class="content">
                                    <h2>مبيعات الاسبوع !</h2>
                                    <p>تخفيض بنسبة 50 % على الموقع</p>
                                    <div class="button">
                                        <a class="btn" href="index.php">تسوق الان</a>
                                    </div>
                                </div>
                            </div>
                            <!-- Start Small Banner -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<!-- .......................................... -->
<section class="trending-product section" style="margin-top: 12px;">
<div class="container">
<div class="row">
                <div class="col-12">
                    <div class="section-title">
                        <h2></h2>
                        <p>هناك العديد من الأنواع المتوفرة لنصوص لوريم إيبسوم، لكن الأغلبية متوفرة
                            عانى من التغيير في شكل ما.</p>
                    </div>
                </div>
            </div>
            <div class="row" id="searchResult">
                
</div>
</div>

</section>


<?php
include "footer.php"
?>
 

<script src="../assets/js/jquery.js"></script>
<script type="text/javascript">
    $(document).ready(function()
    {   
        var main="main";
        $.ajax({
            url:"show_index.php",
            data:
            {main:main},
            method:"post",
            success:function(data)
            {
                $("#searchResult").html(data);
            }
        });
        

    });
    </script>
    <script src="../assets/js/bootstrap.min.js"></script>
    <script src="../assets/js/tiny-slider.js"></script>
    <script src="../assets/js/glightbox.min.js"></script>
    <script src="../assets/js/main.js"></script>
    <script type="text/javascript">
        //========= Hero Slider 
        tns({
            container: '.hero-slider',
            slideBy: 'page',
            autoplay: true,
            autoplayButtonOutput: false,
            mouseDrag: true,
            gutter: 0,
            items: 1,
            nav: false,
            controls: true,
            controlsText: ['<i class="lni lni-chevron-left"></i>', '<i class="lni lni-chevron-right"></i>'],
        });

        //======== Brand Slider
        tns({
            container: '.brands-logo-carousel',
            autoplay: true,
            autoplayButtonOutput: false,
            mouseDrag: true,
            gutter: 15,
            nav: false,
            controls: false,
            responsive: {
                0: {
                    items: 1,
                },
                540: {
                    items: 3,
                },
                768: {
                    items: 5,
                },
                992: {
                    items: 6,
                }
            }
        });
    </script>