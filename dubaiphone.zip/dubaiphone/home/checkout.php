
<?php
session_start();
require_once "../assets/dataBase/allTabel.php";
$db = new Database();

    if(isset($_SESSION["user"]))
    {
        $passW = $db->Update("UPDATE order_client_register SET 	sure=?  WHERE 	email_user = ? ",[1,$_SESSION["user"]]);
    }
    if(isset($_SESSION["temp_user"]))
    {
        $passW = $db->Update("UPDATE orderr SET 	sure=?  WHERE 	email = ? ",[1,$_SESSION["temp_user"]]);
    }
    
    
?>
<script>window.location = "index.php";</script>