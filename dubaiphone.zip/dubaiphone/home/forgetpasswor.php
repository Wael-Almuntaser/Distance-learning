<?php
include "header.php";
if(isset($_SESSION['user']))
{
    ?>
    <script>window.location = "index.php";</script>
    <?php
}
?>
  <div class="container_R" id="container_l">
  <div id="error" class="alert alert-danger alert-dismissible fade show w-100" role="alert"></div>
    <div class="forms">
        <div class="form-content">
          <div class="login-form">
            <div class="title">استرجاع كلمة السر </div>
          <form action="#" id="sample_form" method="post">
          <div class="user-details">
                <div class="input-boxx">
                    <span class="details">إدخل الايميل </span>
                    <input type="email" placeholder="إدخل الايميل" id="email" name="email">
                  </div>
              <div class="button">
              <input type="submit" id="submit" name="submit" value="ارسال ">
              </div>
              <input type="hidden" id="forgetpassword" name="forgetpassword" value="forgetpassword">
              <div class="text sign-up-text">اذهب الى? <a href="Login.php">تسجيل الدخول</a></div>
</div>
        </form>
        <div class="preloader-inner" id="preloader_1">
          <div class="preloader-icon">
              <span></span>
              <span></span>
          </div>
      </div>
      </div>
    </div>
    </div>
  </div>
  <?php
include "footer.php"
?>
<script>
  $(document).ready(function(){
    $("#preloader_1").hide();
    $("#error").hide();
    $('#sample_form').on('submit', function(event){
      event.preventDefault();
        $.ajax({
          url : "../assets/dataBase/UserDB.php",
          method:"POST",
          data: new FormData(this),
          contentType:false,
          cache:false,
          processData:false,
          success: function(response){
            if(response == 1){
              $("#preloader_1").show();
              $("#error").removeClass("alert-danger");
              $("#error").addClass("alert-primary");
              $("#error").show().html("جاري التنفيذ");
              setInterval(function () {
             window.location = "code.php";
              }, 2000);
           
               
            }
            else{
             $("#error").show().html(response);
            }
					}
        })  
    
      
        return false;
    })
  })

</script>