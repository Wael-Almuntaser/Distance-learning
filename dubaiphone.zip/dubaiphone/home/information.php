<?php
include "header.php"
?>

<body>

<section class="item-details section">
<div class="container">
<div class="top-area">
<div class="row align-items-center">
<div class="col-lg-6 col-md-12 col-12">
<div class="product-images">
<main id="gallery">
<div class="main-img">
<img src="<?php echo $_GET['path']  ?>" id="current" alt="#">
</div>
</main>
</div>
</div>
<div class="col-lg-6 col-md-12 col-12">
<div class="product-info">

<h4 class="info-text"><?php echo $_GET['name']  ?></h4>
<div class="container_R" id="container_l">
    <div id="error" class="alert alert-danger alert-dismissible fade show w-100" role="alert"></div>
      <div class="forms">
          <div class="form-content">
            <div class="login-form">
              <div class="title">تفاصيل</div>
            <form action="#" id="sample_form" method="post">
            <div class="user-details">
                <div class="input-boxx">
                    <span class="details">العدد</span>
                    <input type="number" placeholder="ادخل العدد" id="number_" name="number_" >
                  </div>
                  <?php
                    if(!isset($_SESSION['user'])){ ?>
                    <div class="input-boxx">
                    <span class="details">الاسم</span>
                    <input type="text" placeholder="ادخل الاسم" id="name" name="name" >
                  </div>
                  <div class="input-boxx">
                      <span class="details">الايميل</span>
                      <input type="email" placeholder="ادخل الايميل" id="email" name="email">
                    </div>
                    <div class="input-boxx">
                      <span class="details">الهاتف</span>
                      <input type="number" placeholder="ادخل رقم الهاتف" id="phone" name="phone" >
                    </div>
                    <?php
                    }
                  ?>

                    <input type="hidden" name="buy" id="buy">
                    <div class="input-boxx">
                        <span class="details">(العنوان وغيرها) تفاصيل اخرى  </span>
                        <textarea rows="10" cols="10" style="resize: none; width: 100%;" id="detial" name="detial"></textarea>
                    </div>

  </div>

    <div class="button cart-button">
    <input type="submit" id="submit" name="submit" value="اضافه للسله" class="btn" style="width: 100%;">
    <br>
    <br>
    <button class="btn" style="width: 100%;"><a href="index.php" style="color:white">الرجوع الي الصفحة الرئيسية</a></button>
    
    </div>
          </form>
          <div class="preloader-inner" id="preloader_1">
            <div class="preloader-icon">
                <span></span>
                <span></span>
            </div>
        </div>
        </div>
      </div>
      </div>
    </div>

</div>
<br>
<div class="bottom-content">
<div class="row align-items-end">


<div class="col-lg-4 col-md-4 col-12">

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="product-details-info">
<div class="single-block">
<div class="row">
<div class="col-lg-6 col-12">
<div class="info-body custom-responsive-margin">
<h4 id="ma">المواصفات</h4>

<?php
$desc=$_GET["detial"];
$detial=explode(".",$desc);
for($i=0;$i<count($detial);$i++)
{ ?>
<p id="ma"><?php echo $detial[$i] ?></p>
<?php }

?>



</div>
</div>
</div>
</div>
</div>
</div>
</section>

</body>

<?php
include "footer.php"
?>
<script>
  $(document).ready(function(){
    $("#preloader_1").hide();
    $("#error").hide();
    
    $('#sample_form').on('submit', function(event){ 
      event.preventDefault();
        $.ajax({
          url : "../admin/AddDB.php ? id=<?php echo $_GET['id'] ?> &old=<?php echo $_GET['old'] ?> &new=<?php echo $_GET['new'] ?> &tb=<?php echo $_GET['tbb'] ?> & pathh=<?php echo $_GET['path'] ?> ",
          method:"POST",
          data: new FormData(this),
          contentType:false,
          cache:false,
          processData:false,
          success: function(response){
            if(response == 1){
              $("#preloader_1").show();
              $("#error").removeClass("alert-danger");
              $("#error").addClass("alert-primary");
              $("#error").show().html("جاري التنفيذ");
              setInterval(function () {
             window.location = "index.php";
              }, 2000);
           
               
            }
            else{
             $("#error").show().html(response);
            }
					}
        })  
    
      
        return false;
    })
  })

</script>
