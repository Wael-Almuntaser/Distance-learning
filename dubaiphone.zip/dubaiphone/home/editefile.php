<?php
include "header_user.php";

?>
  <div class="container_R" id="container_l" style="margin-top: 15%;">
  <div id="error" class="alert alert-danger alert-dismissible fade show w-100" role="alert"></div>
    <div class="forms">
        <div class="form-content">
          <div class="login-form">
            <div class="title">Change Password</div>
          <form action="#" id="sample_form" method="post">
          <div class="user-details">
            <div class="input-boxx">
              <span class="details">Password</span>
              <input type="password" placeholder="Enter your password" id="password" name="password" >
            </div>
            <div class="input-boxx">
              <span class="details">Confirm Password</span>
              <input type="password" placeholder="Confirm your password" id="Confpassword" name="Confpassword" >
            </div>
                  <input type="hidden" id="addmin_pass" name="user_pass" value="user_pass">
              <div class="button">
                <input type="submit" id="submit" name="submit" value="Change">
              </div>
</div>
        </form>
        <div class="preloader-inner" id="preloader_1">
          <div class="preloader-icon">
              <span></span>
              <span></span>
          </div>
      </div>
      </div>
    </div>
    </div>
  </div>
  <?php
include "footer_user.php"; 
?>
  <script src="../assets/js/jquery.js"></script>
<script type="text/javascript">
  $(document).ready(function(){
    $("#preloader_1").hide();
    $("#error").hide();
    $('#sample_form').on('submit', function(event){
      event.preventDefault();
        $.ajax({
          url : "../assets/dataBase/UserDB.php",
          method:"POST",
          data: new FormData(this),
          contentType:false,
          cache:false,
          processData:false,
          success: function(response){
            if(response == 1){
              $("#preloader_1").show();
              $("#error").removeClass("alert-danger");
              $("#error").addClass("alert-primary");
              $("#error").show().html("Account created success");
              setInterval(function () {
             window.location = "dashbord.php";
              }, 2000);
           
               
            }
            else{
             $("#error").show().html(response);
            }
					}
        })  
    
      
        return false;
    })
  });



<!-- //   function Unlock(user_id)
//         {
//             alert("Unlock")
//             var user_id=id;
//         $.ajax({
//             url:"aaa.php ",
//             data:
//             {
//                 user_id:user_id,
//             },
//             method:"post",
//             success:function(data)
//             {
//                 $("#searchResult").html(data);
//             }
//         }); 
//         }


//         function lock(id)
//         {
//             alert("lock");
//         } -->

</script>
