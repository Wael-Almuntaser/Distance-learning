<!-- <?php
// include "../heaader_footer/header.php"
// ?>
<script>
                function uploading()
    {
        let reader=new FileReader();
        reader.readAsDataURL(document.getElementById('upload_image').files[0]);
        reader.addEventListener('load',()=>{
            img=document.getElementById("image_chose").style.backgroundImage='url('+reader.result+')';
            document.getElementById("add_icon").style.display="none";
        });
    }
</script>
  <div class="container_R" id="container_A">
    <div class="forms">
        <div class="form-content">
          <div class="login-form">
            <div class="title">Add Iphon</div>
          <form action="#">
            <div class="show_img">
                <span>Add Screen Shot Of Dispote</span>
                <i class="icon_add" id="add_icon"></i>
                <input type="file" class="up_input" id="upload_image" name="upload_image" onchange="uploading(this)">
            </div>
          <div class="user-details">
                <div class="input-boxx">
                    <span class="details">Name</span>
                    <input type="text" placeholder="Enter The Name" id="name" name="name">
                  </div>
                  <div class="input-boxx">
                    <span class="details">Price</span>
                    <input type="text" placeholder="Enter your password" id="Price" name="Price">
                  </div>
                  <div class="col-lg-4 col-md-4 col-12">
                    <div class="form-group">
                        <span class="details">Memory</span>
                        <select class="form-control" id="color">
                            <option>1 Tura </option>
                            <option>512 Giga</option>
                            <option>256 Giga</option>
                            <option>128 Giga</option>
                        </select>
                    </div>
                </div>
                <div class="input-boxx">
                    <span class="details">Number</span>
                    <input type="number" placeholder="Enter The avariable number" id="number_" name="number_">
                  </div>
                <div class="input-boxx">
                    <span class="details">Discound</span>
                    <input type="text" placeholder="Enter your Discound" id="Discond" name="Discond">
                  </div>
                  <div class="input-boxx">
                    <span class="details">Discribtion</span>
                    <textarea name="Discribtion" id="Discribtion" rows="10" cols="10">

                    </textarea>
                  </div>

              <div class="button">
                <input type="submit" id="submit" name="submit" value="Add">
              </div>
            
</div>
        </form>
      </div>
    </div>
    </div>
  </div>

  <?php
// include "../heaader_footer/footer.php"
?> -->